<?php
/**
 * Look-ups: which countries visitors open in the planner, month by month.
 *
 * When a visitor opens a country's card, the page sends that country, and
 * nothing else, to gtp/v1/look: once a country a page view. The site adds one
 * to that country's count for the month and keeps nothing more: no time,
 * page, address, cookie or browser. Thirteen months are kept. Nobody signed
 * in is counted, nor a crawler, nor a request from another site, nor a
 * country the planner does not know, and nothing at all while the planner is
 * in preview or counting is switched off.
 *
 * Travel Planner > Look-ups shows the counts beside this site's guide for
 * each country, or none: the most looked-up with no guide are the guides to
 * write next. The last full month's most looked-up countries (names only,
 * GTP_POPULAR_COUNT of them, each looked up at least GTP_POPULAR_MIN times)
 * are public at gtp/v1/popular for Gildhart's monthly report, unless the
 * settings say not.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_LOOKUPS_OPTION = 'gtp_lookups';        // 'YYYY-MM' => country slug => count
const GTP_LOOKUPS_SINCE  = 'gtp_lookups_since';  // the day the first look-up was counted
const GTP_LOOKUPS_KEEP   = 13;                   // months kept
const GTP_POPULAR_COUNT  = 5;
const GTP_POPULAR_MIN    = 3;

/** The month a moment falls in, by the site's clock: "2026-11". */
function gtp_lookups_month( $ts = null ) {
	return wp_date( 'Y-m', null === $ts ? gtp_notices_now() : $ts );
}

/** The month before a "YYYY-MM". */
function gtp_lookups_month_before( $month ) {
	list( $y, $m ) = array_map( 'intval', explode( '-', $month ) );
	return 1 === $m ? sprintf( '%04d-12', $y - 1 ) : sprintf( '%04d-%02d', $y, $m - 1 );
}

/** Every count kept: month => slug => count, oldest month first. */
function gtp_lookups() {
	$d = get_option( GTP_LOOKUPS_OPTION, array() );
	return is_array( $d ) ? $d : array();
}

/** Whether a look-up would be counted at all: the planner public, and counting on. */
function gtp_lookups_counting() {
	return gtp_public() && (bool) gtp_setting( 'count_lookups', true );
}

/** A slug the planner knows => its name. */
function gtp_country_names() {
	static $names = null;
	if ( null === $names ) {
		$names = array();
		foreach ( gtp_countries() as $c ) {
			if ( ! empty( $c['slug'] ) ) { $names[ (string) $c['slug'] ] = (string) ( $c['name'] ?? $c['slug'] ); }
		}
	}
	return $names;
}

/** One more look-up of a country this month. False, and nothing kept, for a country the planner does not know. */
function gtp_lookups_add( $slug ) {
	$slug = strtolower( trim( (string) $slug ) );
	if ( ! isset( gtp_country_names()[ $slug ] ) ) { return false; }
	$all   = gtp_lookups();
	$month = gtp_lookups_month();
	if ( ! isset( $all[ $month ] ) || ! is_array( $all[ $month ] ) ) { $all[ $month ] = array(); }
	$all[ $month ][ $slug ] = (int) ( $all[ $month ][ $slug ] ?? 0 ) + 1;
	ksort( $all );
	$all = array_slice( $all, -GTP_LOOKUPS_KEEP, null, true );
	update_option( GTP_LOOKUPS_OPTION, $all, false );
	if ( ! get_option( GTP_LOOKUPS_SINCE ) ) { update_option( GTP_LOOKUPS_SINCE, wp_date( 'Y-m-d', gtp_notices_now() ), false ); }
	return true;
}

/**
 * Whether a request to count comes from a visitor to this site: a browser,
 * not a crawler, sent from one of this site's own pages. A request that says
 * neither where it came from (Origin) nor which page sent it (Referer) is a
 * script's, not a page's, and is not counted.
 */
function gtp_lookups_from_here( $ua, $origin, $referer ) {
	$ua = (string) $ua;
	if ( '' === trim( $ua ) || preg_match( '/bot|crawl|spider|slurp|preview|fetch|curl|wget|python|httpclient|headlesschrome|lighthouse|pingdom|monitor/i', $ua ) ) { return false; }
	$home = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	$from = '' !== (string) $origin ? (string) $origin : (string) $referer;
	if ( '' === $from ) { return false; }
	return strtolower( (string) wp_parse_url( $from, PHP_URL_HOST ) ) === $home;
}

/** The answer to gtp/v1/look: always "No Content", counted or not, so it tells a script nothing. */
function gtp_lookups_rest_look( $request ) {
	if ( gtp_lookups_counting() && gtp_lookups_from_here( $request->get_header( 'user_agent' ), $request->get_header( 'origin' ), $request->get_header( 'referer' ) ) ) {
		gtp_lookups_add( (string) $request->get_param( 'c' ) );
	}
	return new WP_REST_Response( null, 204 );
}

/**
 * The last full month's most looked-up countries, names only, for Gildhart's
 * monthly report: each looked up at least GTP_POPULAR_MIN times, the most
 * first. Null when the settings keep them private.
 */
function gtp_lookups_popular() {
	if ( ! gtp_setting( 'share_popular', true ) ) { return null; }
	$month  = gtp_lookups_month_before( gtp_lookups_month() );
	$counts = (array) ( gtp_lookups()[ $month ] ?? array() );
	$names  = gtp_country_names();
	$rows   = array();
	foreach ( $counts as $slug => $n ) {
		if ( (int) $n >= GTP_POPULAR_MIN && isset( $names[ $slug ] ) ) { $rows[] = array( 'slug' => (string) $slug, 'name' => $names[ $slug ], 'n' => (int) $n ); }
	}
	usort( $rows, function ( $a, $b ) { return $b['n'] <=> $a['n'] ?: strcmp( $a['name'], $b['name'] ); } );
	$out = array();
	foreach ( array_slice( $rows, 0, GTP_POPULAR_COUNT ) as $r ) {
		$out[] = array( 'slug' => $r['slug'], 'name' => $r['name'], 'guide' => '' !== gtp_guide_url( $r['slug'] ) );
	}
	return array( 'month' => $month, 'since' => (string) get_option( GTP_LOOKUPS_SINCE, '' ), 'countries' => $out );
}

function gtp_lookups_rest_popular() {
	$p = gtp_lookups_popular();
	$r = new WP_REST_Response( null === $p ? array( 'shared' => false ) : array( 'shared' => true ) + $p, 200 );
	$r->header( 'Cache-Control', 'public, max-age=3600' );
	return $r;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'gtp/v1', '/look', array(
		'methods'             => 'POST',
		'callback'            => 'gtp_lookups_rest_look',
		'permission_callback' => '__return_true',
	) );
	register_rest_route( 'gtp/v1', '/popular', array(
		'methods'             => 'GET',
		'callback'            => 'gtp_lookups_rest_popular',
		'permission_callback' => '__return_true',
	) );
} );

/** Where the planner sends a look-up: only for a visitor who would be counted, so a signed-in editor's page sends nothing. */
function gtp_lookups_url() {
	if ( ! gtp_lookups_counting() || ( function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) ) { return ''; }
	return function_exists( 'rest_url' ) ? (string) rest_url( 'gtp/v1/look' ) : '';
}

/* ---- Travel Planner > Look-ups ---------------------------------------------- */

add_action( 'admin_menu', function () {
	add_submenu_page( 'gtp-settings', 'Country look-ups', 'Look-ups', 'manage_options', 'gtp-lookups', 'gtp_admin_lookups_page' );
}, 20 );

/** One line for the site's privacy notice, saying exactly what is kept. */
function gtp_lookups_privacy_line() {
	return 'Our travel planner counts how many times each country is looked up each month. It keeps only the country and the month: nothing about you, no cookie and no IP address.';
}

function gtp_admin_lookups_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$all   = gtp_lookups();
	$month = gtp_lookups_month();
	$prev  = gtp_lookups_month_before( $month );
	$names = gtp_country_names();
	$rows  = array();
	foreach ( $all as $m => $counts ) {
		foreach ( (array) $counts as $slug => $n ) {
			if ( ! isset( $names[ $slug ] ) ) { continue; }
			if ( ! isset( $rows[ $slug ] ) ) { $rows[ $slug ] = array( 'now' => 0, 'last' => 0, 'year' => 0 ); }
			$rows[ $slug ]['year'] += (int) $n;
			if ( $m === $month ) { $rows[ $slug ]['now'] += (int) $n; }
			if ( $m === $prev ) { $rows[ $slug ]['last'] += (int) $n; }
		}
	}
	uksort( $rows, function ( $a, $b ) use ( $rows, $names ) {
		return $rows[ $b ]['year'] <=> $rows[ $a ]['year'] ?: $rows[ $b ]['now'] <=> $rows[ $a ]['now'] ?: strcmp( $names[ $a ], $names[ $b ] );
	} );
	$wanted = array();
	foreach ( $rows as $slug => $r ) {
		if ( '' === gtp_guide_url( $slug ) ) { $wanted[] = $names[ $slug ] . ' (' . $r['year'] . ')'; }
		if ( count( $wanted ) >= 5 ) { break; }
	}
	$since = (string) get_option( GTP_LOOKUPS_SINCE, '' );
	$label = function ( $m ) { $t = strtotime( $m . '-01 00:00:00 UTC' ); return $t ? gmdate( 'F Y', $t ) : $m; };
	?>
	<div class="wrap" data-gtp-admin="lookups">
		<h1>Country look-ups</h1>
		<p>How many times each country was opened in the travel planner, month by month. Only the country and the month are kept: nothing about the visitor, no cookie and no IP address. Nobody signed in to the site is counted.</p>
		<p data-gtp-lookups-state>
			<?php if ( ! gtp_setting( 'count_lookups', true ) ) : ?>
				<strong>Counting is off</strong> (Settings).
			<?php elseif ( ! gtp_public() ) : ?>
				<strong>Nothing is counted while the planner is in preview.</strong> Counting starts when it is shown to everyone.
			<?php elseif ( '' === $since ) : ?>
				Counting is on. Nothing has been looked up yet.
			<?php else : ?>
				Counting since <strong><?php echo esc_html( gtp_day( $since ) ); ?></strong>.
			<?php endif; ?>
		</p>

		<?php if ( $wanted ) : ?>
		<div class="notice notice-info inline" data-gtp-wanted><p><strong>Most looked up, with no guide on this site:</strong> <?php echo esc_html( implode( ', ', $wanted ) ); ?>. These are the country guides to write next.</p></div>
		<?php endif; ?>

		<table class="widefat striped" style="max-width:900px" data-gtp-lookups>
			<thead><tr><th>Country</th><th><?php echo esc_html( $label( $month ) ); ?> so far</th><th><?php echo esc_html( $label( $prev ) ); ?></th><th>Last 12 months</th><th>This site's guide</th></tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?><tr><td colspan="5">No look-ups yet.</td></tr><?php endif; ?>
			<?php foreach ( array_slice( $rows, 0, 40, true ) as $slug => $r ) : $g = gtp_guide_url( $slug ); ?>
				<tr data-gtp-lookup="<?php echo esc_attr( $slug ); ?>">
					<td><?php echo esc_html( $names[ $slug ] ); ?></td>
					<td><?php echo (int) $r['now']; ?></td>
					<td><?php echo (int) $r['last']; ?></td>
					<td><?php echo (int) $r['year']; ?></td>
					<td><?php if ( '' !== $g ) : ?><a href="<?php echo esc_url( $g ); ?>">Published</a><?php else : ?>None yet<?php endif; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php
		$rc      = gtp_reminder_counts();
		$waiting = count( gtp_reminders() );
		$rnow    = (array) ( $rc[ $month ] ?? array() );
		$rlast   = (array) ( $rc[ $prev ] ?? array() );
		?>
		<h2>Reminders</h2>
		<p data-gtp-reminder-counts>
			<?php if ( ! gtp_setting( 'reminders', true ) ) : ?>
				Reminders are off (Settings).
			<?php else : ?>
				Reminders to book, added by visitors looking more than <?php echo (int) GTP_REMIND_WEEKS; ?> weeks ahead.
				<strong><?php echo esc_html( $label( $month ) ); ?> so far:</strong> <?php echo (int) ( $rnow['calendar'] ?? 0 ); ?> added to a calendar<?php if ( gtp_setting( 'remind_email', false ) ) : ?>, <?php echo (int) ( $rnow['email'] ?? 0 ); ?> asked for by email (<?php echo (int) ( $rnow['sent'] ?? 0 ); ?> sent)<?php endif; ?>.
				<strong><?php echo esc_html( $label( $prev ) ); ?>:</strong> <?php echo (int) ( $rlast['calendar'] ?? 0 ); ?> added to a calendar<?php if ( gtp_setting( 'remind_email', false ) ) : ?>, <?php echo (int) ( $rlast['email'] ?? 0 ); ?> asked for by email (<?php echo (int) ( $rlast['sent'] ?? 0 ); ?> sent)<?php endif; ?>.
				<?php if ( gtp_setting( 'remind_email', false ) ) : ?><span data-gtp-reminders-waiting><?php echo (int) $waiting; ?> waiting to be sent.</span><?php endif; ?>
				These are counts: who asked is never shown here.
			<?php endif; ?>
		</p>

		<h2>For the site's privacy notice</h2>
		<p>Add this line to the privacy notice while counting is on:</p>
		<p><textarea class="large-text" rows="2" readonly data-gtp-privacy-line><?php echo esc_textarea( gtp_lookups_privacy_line() ); ?></textarea></p>
		<?php if ( gtp_setting( 'remind_email', false ) ) : ?>
		<p>And this one, while reminders by email are on:</p>
		<p><textarea class="large-text" rows="2" readonly data-gtp-reminder-privacy><?php echo esc_textarea( gtp_reminders_privacy_line() ); ?></textarea></p>
		<?php endif; ?>
		<p data-gtp-popular-state><?php echo gtp_setting( 'share_popular', true )
			? 'Last month\'s five most looked-up countries, by name and without their counts, are public for Gildhart\'s monthly report. Settings can keep them private.'
			: 'Last month\'s most looked-up countries are kept private (Settings).'; ?></p>
	</div>
	<?php
}
