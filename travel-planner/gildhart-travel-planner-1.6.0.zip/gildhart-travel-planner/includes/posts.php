<?php
/**
 * Posts to share: a new outbreak notice, as something this pharmacy can say today.
 *
 * The reader already knows, each morning, which new notices are for a disease
 * this pharmacy vaccinates against, and emails the pharmacy. What the
 * pharmacy then lacks is the time to write about it. So for each such notice
 * of the last GTP_POSTS_DAYS days the plugin drafts three things: a Google
 * Business Profile post, a short social post and an email. Travel Planner >
 * Posts to share lists them, the ones most worth sharing first: a country
 * this site has a guide for, then the countries its visitors look up most.
 *
 * Nothing is ever posted or sent from here. A person reads the notice, reads
 * the draft, copies it and shares it, and marks it as shared.
 *
 * What a draft says, and never says:
 *   - the three things the reader keeps of a notice: its day, its disease and
 *     its country. None of NaTHNaC's words or figures, which are theirs, and
 *     which a script could misread.
 *   - a travel consultation, and never a vaccine or a price. A post is an
 *     advertisement, and the UK's advertising code does not allow a
 *     prescription-only medicine, which a vaccine is, to be advertised to the
 *     public: that covers a pharmacy's own social posts and emails (CAP Code,
 *     rule 12.12; the ASA's advice is to "promote the consultation itself,
 *     rather than the product"; read 13 November 2026). The vaccines and
 *     their prices stay on the site's own pages, which the post links to.
 *   - nothing to frighten anyone, and nothing that tells a reader what they
 *     need: that is settled at the consultation.
 *   - nothing about a notice filed under several countries, where only
 *     NaTHNaC's own words say which country the disease is in.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_POSTS_SHARED = 'gtp_posts_shared';   // the notices a person has marked as shared: key => the day they did
const GTP_POSTS_DAYS   = 30;                   // how recent a notice is still worth a post
const GTP_POSTS_SHOWN  = 8;                    // how many are drafted on the screen at once
const GTP_POST_SOCIAL  = 280;                  // a short post's length, its link included

/**
 * A notice's disease as a post names it ("measles", "hepatitis A", "polio"),
 * or '' for a disease this pharmacy does not vaccinate against. NaTHNaC's own
 * names can carry a strain or the word "vaccine" ("vaccine-derived
 * poliovirus"): a post says the plain name.
 */
function gtp_disease_label( $disease ) {
	$labels = array(
		'japanese encephalitis'   => 'Japanese encephalitis',
		'tick-borne encephalitis' => 'tick-borne encephalitis',
		'tick borne encephalitis' => 'tick-borne encephalitis',
		'hepatitis a'             => 'hepatitis A',
		'hepatitis b'             => 'hepatitis B',
		'yellow fever'            => 'yellow fever',
		'typhoid'                 => 'typhoid',
		'cholera'                 => 'cholera',
		'dengue'                  => 'dengue',
		'chikungunya'             => 'chikungunya',
		'rabies'                  => 'rabies',
		'measles'                 => 'measles',
		'mumps'                   => 'mumps',
		'rubella'                 => 'rubella',
		'diphtheria'              => 'diphtheria',
		'tetanus'                 => 'tetanus',
		'polio'                   => 'polio',
		'cvdpv'                   => 'polio',
		'wpv'                     => 'polio',
		'meningococcal'           => 'meningococcal disease',
		'meningitis'              => 'meningitis',
		'tuberculosis'            => 'tuberculosis',
	);
	$d    = strtolower( (string) $disease );
	$ours = gtp_our_diseases();
	foreach ( $labels as $needle => $label ) {
		if ( in_array( $needle, $ours, true ) && false !== strpos( $d, $needle ) ) { return $label; }
	}
	return '';
}

/** How often each country was looked up here in this month and the two before it. */
function gtp_posts_looks() {
	$all    = gtp_lookups();
	$month  = gtp_lookups_month();
	$months = array( $month, gtp_lookups_month_before( $month ), gtp_lookups_month_before( gtp_lookups_month_before( $month ) ) );
	$out    = array();
	foreach ( $months as $m ) {
		foreach ( (array) ( $all[ $m ] ?? array() ) as $slug => $n ) { $out[ $slug ] = (int) ( $out[ $slug ] ?? 0 ) + (int) $n; }
	}
	return $out;
}

/**
 * A notice as a post could be written about it, or null: one country the
 * planner knows, a disease this pharmacy vaccinates against, and not a notice
 * filed under several countries.
 */
function gtp_post_from_notice( $n ) {
	$names = gtp_country_names();
	$slug  = (string) ( $n['slug'] ?? '' );
	if ( '' === $slug || ! isset( $names[ $slug ] ) || '' !== (string) ( $n['group'] ?? '' ) || count( (array) ( $n['places'] ?? array() ) ) > 1 ) { return null; }
	$label = gtp_disease_label( $n['disease'] ?? '' );
	if ( '' === $label ) { return null; }
	return array(
		'key'     => (string) $n['date'] . '|' . $label . '|' . $slug,
		'date'    => (string) $n['date'],
		'disease' => $label,
		'slug'    => $slug,
		'country' => $names[ $slug ],
		'source'  => (string) ( $n['url'] ?? '' ),
	);
}

/** The notices marked as shared: key => day. Ones older than the notices themselves are forgotten. */
function gtp_posts_shared() {
	$d = get_option( GTP_POSTS_SHARED, array() );
	return is_array( $d ) ? $d : array();
}

/**
 * The notices worth a post, the most worth sharing first: not yet shared,
 * then a country this site has a guide for, then the countries looked up
 * most here, then the newest. One a country and disease.
 */
function gtp_posts_candidates() {
	$looks  = gtp_posts_looks();
	$shared = gtp_posts_shared();
	$seen   = array();
	$out    = array();
	foreach ( gtp_notices_current( GTP_POSTS_DAYS ) as $n ) {
		$c = gtp_post_from_notice( $n );
		if ( ! $c || isset( $seen[ $c['slug'] . '|' . $c['disease'] ] ) ) { continue; }
		$seen[ $c['slug'] . '|' . $c['disease'] ] = true;
		$c['guide']  = gtp_guide_url( $c['slug'] );
		$c['looks']  = (int) ( $looks[ $c['slug'] ] ?? 0 );
		$c['shared'] = (string) ( $shared[ $c['key'] ] ?? '' );
		$out[]       = $c;
	}
	usort( $out, function ( $a, $b ) {
		return ( '' !== $a['shared'] ) <=> ( '' !== $b['shared'] )
			?: ( '' !== $b['guide'] ) <=> ( '' !== $a['guide'] )
			?: $b['looks'] <=> $a['looks']
			?: strcmp( $b['date'], $a['date'] )
			?: strcmp( $a['country'], $b['country'] );
	} );
	return $out;
}

function gtp_post_len( $s ) {
	return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $s, 'UTF-8' ) : strlen( (string) $s );
}

/**
 * The three drafts for a notice: a Google Business Profile post (its words,
 * and the button's address), a short social post and an email. The day, the
 * disease, the country, the consultation and where to book: nothing else.
 */
function gtp_post_drafts( $c ) {
	$name  = (string) gtp_setting( 'pharmacy' );
	$at    = '' !== $name ? ' at ' . $name : '';
	$links = gtp_reminder_links( $c['slug'] );
	$more  = '' !== (string) ( $c['guide'] ?? '' ) ? (string) $c['guide'] : $links['planner'];
	$fact  = 'posted an outbreak notice for ' . $c['disease'] . ' in ' . $c['country'] . ' on ' . gtp_day( $c['date'] );
	$who   = 'NaTHNaC, the UK\'s National Travel Health Network and Centre, ';
	$ask   = 'book a travel consultation' . $at . ' and our pharmacist will go through what the UK guidance lists for your trip.';

	$social = 'Going to ' . $c['country'] . '? NaTHNaC ' . $fact . '. ' . ucfirst( $ask ) . ' ' . $links['book'];
	if ( gtp_post_len( $social ) > GTP_POST_SOCIAL ) {
		$social = 'Going to ' . $c['country'] . '? NaTHNaC has posted an outbreak notice for ' . $c['disease'] . ' there. Book a travel consultation' . $at . ': ' . $links['book'];
	}
	if ( gtp_post_len( $social ) > GTP_POST_SOCIAL ) {
		$social = 'Going to ' . $c['country'] . '? NaTHNaC has posted an outbreak notice for ' . $c['disease'] . ' there. Book a travel consultation: ' . $links['book'];
	}
	return array(
		'google' => array(
			'text'   => 'Travelling to ' . $c['country'] . '? ' . $who . $fact . ".\n\n"
				. 'If ' . $c['country'] . ' is in your plans, ' . $ask . "\n\n" . GTP_REMIND_ADVICE,
			'button' => 'Book',
			'url'    => $links['book'],
		),
		'social' => $social,
		'email'  => array(
			'subject' => 'Travelling to ' . $c['country'] . '? An outbreak notice for ' . $c['disease'],
			'body'    => "Hello,\n\n" . $who . $fact . ".\n\n"
				. 'If ' . $c['country'] . ' is in your plans, ' . $ask . ' ' . GTP_REMIND_ADVICE . "\n\n"
				. 'Book a travel consultation: ' . $links['book'] . "\n"
				. ( '' !== $more ? 'What the UK guidance lists for ' . $c['country'] . ': ' . $more . "\n" : '' )
				. ( '' !== $name ? "\n" . $name : '' ),
		),
	);
}

/** For the reader's email: the line that says posts are ready, or '' when none of these notices makes one. */
function gtp_posts_email_line( $notices ) {
	$n = 0;
	foreach ( (array) $notices as $notice ) { if ( gtp_post_from_notice( $notice ) ) { $n++; } }
	if ( ! $n ) { return ''; }
	return "\n\nReady to share: a Google Business post, a short social post and an email about " . ( 1 === $n ? 'it' : ( $n === count( (array) $notices ) ? 'each of them' : $n . ' of them' ) )
		. ", drafted for you to read and post yourself. Nothing is posted for you.\n" . admin_url( 'admin.php?page=gtp-posts' );
}

/* ---- Travel Planner > Posts to share -------------------------------------------- */

add_action( 'admin_menu', function () {
	add_submenu_page( 'gtp-settings', 'Posts to share', 'Posts to share', 'manage_options', 'gtp-posts', 'gtp_admin_posts_page' );
}, 30 );

add_action( 'admin_post_gtp_post_shared', function () {
	gtp_admin_guard( 'gtp_post_shared' );
	$key  = sanitize_text_field( wp_unslash( $_POST['key'] ?? '' ) );
	$keys = array_column( gtp_posts_candidates(), 'key' );
	$list = gtp_posts_shared();
	if ( in_array( $key, $keys, true ) ) {
		if ( ! empty( $_POST['undo'] ) ) { unset( $list[ $key ] ); } else { $list[ $key ] = wp_date( 'Y-m-d', gtp_notices_now() ); }
	}
	/* Only the notices still on the list are remembered. */
	update_option( GTP_POSTS_SHARED, array_intersect_key( $list, array_flip( $keys ) ), false );
	gtp_admin_back( 'gtp-posts', array( 'gtp' => 'changed' ) );
} );

function gtp_admin_posts_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$all    = gtp_posts_candidates();
	$todo   = array_values( array_filter( $all, function ( $c ) { return '' === $c['shared']; } ) );
	$done   = array_values( array_filter( $all, function ( $c ) { return '' !== $c['shared']; } ) );
	$shown  = array_slice( $todo, 0, GTP_POSTS_SHOWN );
	$state  = gtp_notices_state();
	$button = function ( $key, $undo, $label ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
			<input type="hidden" name="action" value="gtp_post_shared">
			<input type="hidden" name="key" value="<?php echo esc_attr( $key ); ?>">
			<?php if ( $undo ) : ?><input type="hidden" name="undo" value="1"><?php endif; ?>
			<?php wp_nonce_field( 'gtp_post_shared' ); ?>
			<button type="submit" class="button<?php echo $undo ? ' button-link' : ''; ?>" data-gtp-post-mark="<?php echo $undo ? 'undo' : 'shared'; ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	};
	?>
	<div class="wrap" data-gtp-admin="posts">
		<h1>Posts to share</h1>
		<?php gtp_admin_message(); ?>
		<p>When NaTHNaC posts an outbreak notice for a disease you vaccinate against, a post about it is drafted here: for your Google Business Profile, for social media and as an email. <strong>Nothing is posted or sent for you.</strong> Read the notice, read the draft, then copy it and share it yourself.</p>
		<div class="notice notice-warning inline" data-gtp-posts-rule><p><strong>Why no vaccine is named, and no price.</strong> A post is an advertisement. The UK's advertising code (CAP Code, rule 12.12) does not allow a prescription-only medicine, which a vaccine is, to be advertised to the public, and that covers your own social posts and emails. So each draft names the disease, the country and your travel consultation, and links to your own pages, where the vaccines and prices are. If you change a draft, keep to that, and have your responsible pharmacist read it first.</p></div>

		<?php if ( ! $all ) : ?>
			<p data-gtp-posts-none><?php echo '' === (string) $state['read']
				? 'The outbreak notices have not been read yet (Notices).'
				: 'No notice in the last ' . (int) GTP_POSTS_DAYS . ' days is for a disease you vaccinate against, in one country. When one is, it will be drafted here and the notice email will say so.'; ?></p>
		<?php elseif ( ! $shown ) : ?>
			<p data-gtp-posts-none>Every notice of the last <?php echo (int) GTP_POSTS_DAYS; ?> days has been marked as shared.</p>
		<?php endif; ?>

		<?php foreach ( $shown as $i => $c ) :
			$d   = gtp_post_drafts( $c );
			$id  = 'gtp-post-' . $i;
			$why = array();
			if ( '' !== $c['guide'] ) { $why[] = 'this site has a guide for ' . $c['country'] . ', and the email links to it'; }
			if ( $c['looks'] > 0 ) { $why[] = $c['country'] . ' was looked up ' . (int) $c['looks'] . ' time' . ( 1 === (int) $c['looks'] ? '' : 's' ) . ' here in the last three months'; }
			?>
			<div class="card" style="max-width:900px;margin-top:18px" data-gtp-post="<?php echo esc_attr( $c['key'] ); ?>" data-gtp-post-slug="<?php echo esc_attr( $c['slug'] ); ?>">
				<h2 style="margin-top:6px" data-gtp-post-title><?php echo esc_html( ucfirst( $c['disease'] ) . ' in ' . $c['country'] ); ?> <span style="font-weight:400">&middot; notice of <?php echo esc_html( gtp_day( $c['date'] ) ); ?></span></h2>
				<p data-gtp-post-why><?php echo $why ? '<strong>Worth sharing:</strong> ' . esc_html( implode( '; ', $why ) ) . '.' : 'No guide on this site for ' . esc_html( $c['country'] ) . ' yet, and nobody has looked it up here lately.'; ?>
					<?php if ( '' !== $c['source'] ) : ?> <a href="<?php echo esc_url( $c['source'] ); ?>" target="_blank" rel="noopener noreferrer" data-gtp-post-source>Read the notice on TravelHealthPro first</a>.<?php endif; ?></p>

				<h3>Google Business Profile post</h3>
				<p><textarea class="large-text" rows="7" readonly id="<?php echo esc_attr( $id ); ?>-google" data-gtp-draft="google"><?php echo esc_textarea( $d['google']['text'] ); ?></textarea></p>
				<p>Its button: <strong><?php echo esc_html( $d['google']['button'] ); ?></strong>, to <code data-gtp-draft="google-url"><?php echo esc_html( $d['google']['url'] ); ?></code>
					<button type="button" class="button" data-gtp-copy="<?php echo esc_attr( $id ); ?>-google">Copy</button></p>

				<h3>Short social post</h3>
				<p><textarea class="large-text" rows="3" readonly id="<?php echo esc_attr( $id ); ?>-social" data-gtp-draft="social"><?php echo esc_textarea( $d['social'] ); ?></textarea></p>
				<p><?php echo (int) gtp_post_len( $d['social'] ); ?> characters. <button type="button" class="button" data-gtp-copy="<?php echo esc_attr( $id ); ?>-social">Copy</button></p>

				<h3>Email</h3>
				<p><input class="large-text" readonly id="<?php echo esc_attr( $id ); ?>-subject" data-gtp-draft="email-subject" value="<?php echo esc_attr( $d['email']['subject'] ); ?>">
					<button type="button" class="button" data-gtp-copy="<?php echo esc_attr( $id ); ?>-subject">Copy the subject</button></p>
				<p><textarea class="large-text" rows="10" readonly id="<?php echo esc_attr( $id ); ?>-email" data-gtp-draft="email"><?php echo esc_textarea( $d['email']['body'] ); ?></textarea></p>
				<p><button type="button" class="button" data-gtp-copy="<?php echo esc_attr( $id ); ?>-email">Copy the email</button></p>

				<p><?php $button( $c['key'], false, 'Mark as shared' ); ?></p>
			</div>
		<?php endforeach; ?>

		<?php if ( count( $todo ) > count( $shown ) ) : ?>
			<p data-gtp-posts-more><?php echo (int) ( count( $todo ) - count( $shown ) ); ?> more notices could have a post. They appear here as you mark these as shared: one good post is worth more than twenty.</p>
		<?php endif; ?>

		<?php if ( $done ) : ?>
			<h2>Shared</h2>
			<ul data-gtp-posts-shared>
			<?php foreach ( $done as $c ) : ?>
				<li><?php echo esc_html( ucfirst( $c['disease'] ) . ' in ' . $c['country'] . ', notice of ' . gtp_day( $c['date'] ) . ': marked as shared on ' . gtp_day( $c['shared'] ) . '.' ); ?> <?php $button( $c['key'], true, 'Not shared after all' ); ?></li>
			<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<script>
	(function () {
		Array.prototype.forEach.call(document.querySelectorAll('[data-gtp-copy]'), function (b) {
			var label = b.textContent;
			b.addEventListener('click', function () {
				var t = document.getElementById(b.getAttribute('data-gtp-copy'));
				if (!t) { return; }
				var done = function () { b.textContent = 'Copied'; setTimeout(function () { b.textContent = label; }, 1500); };
				t.focus(); t.select();
				if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t.value).then(done, function () { document.execCommand('copy'); done(); }); }
				else { document.execCommand('copy'); done(); }
			});
		});
	})();
	</script>
	<?php
}
