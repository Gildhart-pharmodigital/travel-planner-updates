<?php
/**
 * Removing the plugin removes what it kept: its settings, the notices it
 * read and the ones added by hand, its daily reading, its last look at the
 * updates file, the look-up counts, the guide and planner pages it found,
 * any email reminder still waiting and the reminder counts, and which posts
 * were marked as shared.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
delete_option( 'gtp_settings' );
delete_option( 'gtp_notices' );
delete_option( 'gtp_notices_shown' );
delete_option( 'gtp_version_seen' );
delete_transient( 'gtp_update_info' );
delete_option( 'gtp_lookups' );
delete_option( 'gtp_lookups_since' );
delete_option( 'gtp_guide_pages' );
delete_option( 'gtp_planner_page' );
delete_option( 'gtp_licence_grace' );
delete_option( 'gtp_licence_revoked' );
delete_option( 'gtp_reminders' );
delete_option( 'gtp_reminder_counts' );
delete_transient( 'gtp_reminders_hour' );
delete_option( 'gtp_posts_shared' );
wp_clear_scheduled_hook( 'gtp_read_notices' );
