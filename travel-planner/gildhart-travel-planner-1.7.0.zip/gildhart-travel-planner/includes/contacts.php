<?php
/**
 * Contacts: the people who asked this pharmacy to keep in touch.
 *
 * Someone who asks for an email reminder (includes/reminders.php) can also
 * tick a second box, unticked until they tick it: "Also email me travel
 * health news and offers from this pharmacy". Those who do are kept here,
 * with their first name if they gave one, their email address, the trip they
 * were planning, the day they agreed and the exact words they agreed to.
 * Travel Planner > Contacts lists them and downloads them as a CSV file for
 * the pharmacy's own email tool. Those who do not tick it get their reminder
 * and are deleted, as before.
 *
 * What makes it theirs to keep:
 *   - a box of its own, apart from the reminder's, never ticked for them: the
 *     law on marketing by email asks for agreement to that, specifically
 *     (Privacy and Electronic Communications Regulations 2003, reg. 22), and
 *     it is the ground for keeping the details at all (UK GDPR, consent);
 *   - it says what they will get (news and offers), how (email), from whom,
 *     and how long the details are kept (until they unsubscribe);
 *   - a link that stops it in every email the plugin sends them. The link
 *     opens a page with one button (a mail service opens every link in an
 *     email, so opening it alone does nothing). Stopping takes them off the
 *     list at once, tells the pharmacy so, and keeps their
 *     address on a short "asked to stop" list so a copy of the list made
 *     earlier can be put right;
 *   - WordPress's own Export and Erase Personal Data tools find and delete
 *     them.
 *
 * The plugin sends them nothing but the reminder they asked for: the
 * pharmacy sends the news, from its own email tool, which must carry its own
 * way to unsubscribe. Email only: nobody here has agreed to a text message,
 * and no phone number is asked for.
 *
 * It is on only with email reminders, and only while the settings say so
 * (remind_keep); the site's privacy notice carries the line shown beside the
 * switch.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_CONTACTS_OPTION  = 'gtp_contacts';          // email, lower case => name, email, slug, fly, made, words, token
const GTP_CONTACTS_STOPPED = 'gtp_contacts_stopped';  // email, lower case => the day they asked to stop
const GTP_CONTACTS_MAX     = 5000;
const GTP_CONTACTS_STOP_DAYS = 400;                   // how long an "asked to stop" is shown, so a copied list can be put right

/** Whether the reminder's form also asks to keep in touch: only with email reminders on, and the settings saying so. */
function gtp_contacts_on() {
	return gtp_reminders_email_on() && (bool) gtp_setting( 'remind_keep', true );
}

function gtp_contacts() {
	$d = get_option( GTP_CONTACTS_OPTION, array() );
	return is_array( $d ) ? $d : array();
}

function gtp_contacts_save( $rows ) {
	if ( $rows ) { update_option( GTP_CONTACTS_OPTION, $rows, false ); } else { delete_option( GTP_CONTACTS_OPTION ); }
}

/** Who asked to stop, and when: the newest first, none older than GTP_CONTACTS_STOP_DAYS days. */
function gtp_contacts_stopped() {
	$d   = get_option( GTP_CONTACTS_STOPPED, array() );
	$d   = is_array( $d ) ? $d : array();
	$cut = gmdate( 'Y-m-d', gtp_notices_now() - GTP_CONTACTS_STOP_DAYS * DAY_IN_SECONDS );
	$d   = array_filter( $d, function ( $day ) use ( $cut ) { return (string) $day >= $cut; } );
	arsort( $d );
	return $d;
}

/** What the second box says, word for word as the card shows it: {pharmacy} is filled in there, and here when it is kept. */
function gtp_contacts_words() {
	return 'Also email me travel health news and offers from {pharmacy}. {pharmacy} keeps my first name, my email address and this trip for that, until I unsubscribe.';
}

/** One line for the site's privacy notice, saying exactly what the contacts list keeps, why and for how long. */
function gtp_contacts_privacy_line() {
	return 'If you also ask our travel planner to keep in touch, we keep your first name, your email address, the country and your travel date to email you travel health news and offers, until you unsubscribe. Every email has a link to do that.';
}

/** A first name as it is kept: letters, spaces, hyphens and apostrophes, forty at most. '' for anything else. */
function gtp_contact_name( $raw ) {
	if ( ! is_string( $raw ) ) { return ''; }
	$name = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $raw ) ) );
	$name = function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 40, 'UTF-8' ) : substr( $name, 0, 40 );
	return preg_match( '/^[\p{L}][\p{L} \'’\-]*$/u', $name ) ? $name : '';
}

/** The link that takes someone off the list. $all: and deletes any reminder of theirs still waiting, for someone who asked for none of it. */
function gtp_contact_stop_url( $token, $all = false ) {
	return add_query_arg( $all ? array( 'gtp_contact_stop' => $token, 'all' => 1 ) : array( 'gtp_contact_stop' => $token ), gtp_calendar_url() );
}

/** The contact with this address, or null. */
function gtp_contact_of( $email ) {
	$rows = gtp_contacts();
	return $rows[ strtolower( trim( (string) $email ) ) ] ?? null;
}

/**
 * Keep someone who ticked the box. Returns their token ('' when the list is
 * full). Someone already on it keeps the day they first agreed; their name
 * and trip are brought up to date.
 */
function gtp_contacts_add( $email, $name, $trip ) {
	$rows = gtp_contacts();
	$key  = strtolower( trim( (string) $email ) );
	$had  = $rows[ $key ] ?? null;
	if ( ! $had && count( $rows ) >= GTP_CONTACTS_MAX ) { return ''; }
	$pharmacy     = (string) gtp_setting( 'pharmacy' );
	$rows[ $key ] = array(
		'name'  => '' !== $name ? $name : (string) ( $had['name'] ?? '' ),
		'email' => (string) ( $had['email'] ?? $email ),
		'slug'  => $trip['slug'],
		'fly'   => $trip['fly'],
		'made'  => (string) ( $had['made'] ?? wp_date( 'Y-m-d', gtp_notices_now() ) ),
		'words' => (string) ( $had['words'] ?? str_replace( '{pharmacy}', '' !== $pharmacy ? $pharmacy : 'the pharmacy', gtp_contacts_words() ) ),
		'token' => (string) ( $had['token'] ?? bin2hex( random_bytes( 16 ) ) ),
	);
	gtp_contacts_save( $rows );
	/* Someone who had asked to stop and now asks again is no longer on that list. */
	$stopped = get_option( GTP_CONTACTS_STOPPED, array() );
	if ( is_array( $stopped ) && isset( $stopped[ $key ] ) ) { unset( $stopped[ $key ] ); update_option( GTP_CONTACTS_STOPPED, $stopped, false ); }
	if ( ! $had ) { gtp_reminder_count( 'kept' ); }
	return $rows[ $key ]['token'];
}

/** Take an address off the list. $note: whether it goes on the "asked to stop" list (not when a person's data is erased). */
function gtp_contacts_remove( $email, $note = true ) {
	$rows = gtp_contacts();
	$key  = strtolower( trim( (string) $email ) );
	if ( ! isset( $rows[ $key ] ) ) { return false; }
	unset( $rows[ $key ] );
	gtp_contacts_save( $rows );
	if ( $note ) {
		$stopped         = gtp_contacts_stopped();
		$stopped[ $key ] = wp_date( 'Y-m-d', gtp_notices_now() );
		update_option( GTP_CONTACTS_STOPPED, $stopped, false );
	}
	return true;
}

/* ?gtp_contact_stop=<token>: the page asks; its button takes them off the list, the pharmacy is told, and the page says so. */
add_action( 'init', function () {
	if ( ! isset( $_GET['gtp_contact_stop'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification -- the token is the key: only the emails sent to them carry it
	$token = preg_replace( '/[^0-9a-f]/', '', (string) wp_unslash( $_GET['gtp_contact_stop'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$gone  = false;
	$all   = ! empty( $_GET['all'] ); // phpcs:ignore WordPress.Security.NonceVerification
	foreach ( gtp_contacts() as $key => $r ) {
		if ( '' === $token || ! hash_equals( (string) $r['token'], $token ) ) { continue; }
		/* Opened, the link only asks: a mail service opens every link in an email before its reader does. */
		if ( ! gtp_link_confirmed() ) {
			$from = '' !== (string) gtp_setting( 'pharmacy' ) ? (string) gtp_setting( 'pharmacy' ) : 'us';
			if ( $all ) { gtp_link_ask( 'Travel news', 'Delete everything kept about you by our travel planner: your reminder, and your place on the list for travel health news and offers from ' . $from . '?', 'Yes, delete it all' ); }
			gtp_link_ask( 'Travel news', 'Stop travel health news and offers from ' . $from . ', and be taken off the list?', 'Yes, take me off the list' );
		}
		$gone = gtp_contacts_remove( $key );
		/* "Delete everything": the reminder they did not ask for goes too. */
		if ( $all ) { gtp_reminders_erase( $key ); }
		break;
	}
	if ( $gone ) {
		gtp_reminder_count( 'stopped' );
		/* The pharmacy is told that someone left, not who: the screen shows who, to those who may see it. */
		wp_mail(
			gtp_notices_alert_to(),
			'[' . gtp_setting( 'pharmacy' ) . '] Someone has left your travel contacts list',
			"Someone on your travel contacts list has asked to stop hearing from you. They have been taken off the list.\n\n"
			. "If you copied the list into an email tool before today, take them off there too. Travel Planner > Contacts shows who, under \"Asked to stop\":\n"
			. admin_url( 'admin.php?page=gtp-contacts' )
		);
	}
	nocache_headers();
	wp_die(
		esc_html( $gone
			? ( $all ? 'Everything we held about you has been deleted. You will hear nothing more from us.' : 'You have been taken off the list. You will get no more news or offers from us.' )
			: 'You are not on the list: you were taken off it already, and you will get no news or offers from us.' ),
		'Travel news',
		array( 'response' => 200 )
	);
}, 20 );

/* WordPress's own privacy tools: a contact is exported with a person's data, and erased with it. */
function gtp_contacts_export( $email, $page = 1 ) {
	$r = gtp_contact_of( $email );
	if ( ! $r ) { return array( 'data' => array(), 'done' => true ); }
	$names = gtp_country_names();
	return array(
		'data' => array( array(
			'group_id'    => 'gtp-contacts',
			'group_label' => 'Travel Planner contacts list',
			'item_id'     => 'gtp-contact-' . substr( (string) $r['token'], 0, 8 ),
			'data'        => array(
				array( 'name' => 'First name', 'value' => (string) $r['name'] ),
				array( 'name' => 'Email address', 'value' => (string) $r['email'] ),
				array( 'name' => 'Country', 'value' => (string) ( $names[ $r['slug'] ] ?? $r['slug'] ) ),
				array( 'name' => 'Travel date', 'value' => (string) $r['fly'] ),
				array( 'name' => 'Agreed on', 'value' => (string) $r['made'] ),
				array( 'name' => 'Agreed to', 'value' => (string) $r['words'] ),
			),
		) ),
		'done' => true,
	);
}

function gtp_contacts_erase( $email, $page = 1 ) {
	$key  = strtolower( trim( (string) $email ) );
	$gone = gtp_contacts_remove( $key, false ) ? 1 : 0;
	$stopped = get_option( GTP_CONTACTS_STOPPED, array() );
	if ( is_array( $stopped ) && isset( $stopped[ $key ] ) ) { unset( $stopped[ $key ] ); update_option( GTP_CONTACTS_STOPPED, $stopped, false ); $gone++; }
	return array( 'items_removed' => $gone, 'items_retained' => false, 'messages' => array(), 'done' => true );
}
add_filter( 'wp_privacy_personal_data_exporters', function ( $list ) {
	$list['gildhart-travel-planner-contacts'] = array( 'exporter_friendly_name' => 'Travel Planner contacts list', 'callback' => 'gtp_contacts_export' );
	return $list;
} );
add_filter( 'wp_privacy_personal_data_erasers', function ( $list ) {
	$list['gildhart-travel-planner-contacts'] = array( 'eraser_friendly_name' => 'Travel Planner contacts list', 'callback' => 'gtp_contacts_erase' );
	return $list;
} );

/* ---- Travel Planner > Contacts ------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_submenu_page( 'gtp-settings', 'Contacts', 'Contacts', 'manage_options', 'gtp-contacts', 'gtp_admin_contacts_page' );
}, 40 );

/** A cell of a CSV file: quoted, and never read by a spreadsheet as a formula. */
function gtp_csv_cell( $v ) {
	$v = (string) $v;
	if ( '' !== $v && false !== strpos( "=+-@\t\r", $v[0] ) ) { $v = "'" . $v; }
	return '"' . str_replace( '"', '""', $v ) . '"';
}

/** The list as a CSV file: one row a person, newest first. */
function gtp_contacts_csv() {
	$names = gtp_country_names();
	$rows  = gtp_contacts();
	uasort( $rows, function ( $a, $b ) { return strcmp( $b['made'] . $a['email'], $a['made'] . $b['email'] ); } );
	$out = "first_name,email,country,travel_date,agreed_on,agreed_to\r\n";
	foreach ( $rows as $r ) {
		$out .= implode( ',', array_map( 'gtp_csv_cell', array( $r['name'], $r['email'], $names[ $r['slug'] ] ?? $r['slug'], $r['fly'], $r['made'], $r['words'] ) ) ) . "\r\n";
	}
	return $out;
}

add_action( 'admin_post_gtp_contacts_csv', function () {
	gtp_admin_guard( 'gtp_contacts_csv' );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="travel-contacts-' . wp_date( 'Y-m-d', gtp_notices_now() ) . '.csv"' );
	echo gtp_contacts_csv(); // phpcs:ignore WordPress.Security.EscapeOutput -- a CSV file, each cell quoted
	exit;
} );

function gtp_admin_contacts_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$names   = gtp_country_names();
	$rows    = gtp_contacts();
	$stopped = gtp_contacts_stopped();
	uasort( $rows, function ( $a, $b ) { return strcmp( $b['made'] . $a['email'], $a['made'] . $b['email'] ); } );
	?>
	<div class="wrap" data-gtp-admin="contacts">
		<h1>Contacts</h1>
		<p>The people who asked you to keep in touch. Each asked for a reminder in the travel planner and ticked a second box, of their own accord: <em>&ldquo;<?php echo esc_html( str_replace( '{pharmacy}', (string) gtp_setting( 'pharmacy' ), gtp_contacts_words() ) ); ?>&rdquo;</em></p>
		<p data-gtp-contacts-state>
			<?php if ( ! gtp_setting( 'remind_email', false ) ) : ?>
				<strong>Nobody is being asked.</strong> Reminders by email are off (Settings &rsaquo; Reminders), and this list is filled from them.
			<?php elseif ( ! gtp_setting( 'remind_keep', true ) ) : ?>
				<strong>Nobody is being asked.</strong> &ldquo;Also ask whether we may keep in touch&rdquo; is unticked (Settings &rsaquo; Reminders).
			<?php elseif ( ! gtp_public() ) : ?>
				Nobody is asked while the planner is in preview.
			<?php else : ?>
				The planner is asking. <strong><?php echo (int) count( $rows ); ?></strong> on the list.
			<?php endif; ?>
		</p>
		<div class="notice notice-warning inline" data-gtp-contacts-rule><p><strong>What you may send them.</strong> Travel health news and offers, by email: that is what they agreed to. Not a text message, and not anything else. Send it from your own email tool, which must put a way to unsubscribe in every email. A post or an email about a vaccine keeps to the rule on Posts to share: no brand, no price, no claim. Your privacy notice must carry the line below before you ask anyone.</p></div>

		<?php if ( $rows ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:12px 0">
			<input type="hidden" name="action" value="gtp_contacts_csv">
			<?php wp_nonce_field( 'gtp_contacts_csv' ); ?>
			<button type="submit" class="button button-primary" data-gtp-contacts-csv>Download the list as a CSV file</button>
		</form>
		<?php endif; ?>
		<table class="widefat striped" style="max-width:1000px" data-gtp-contacts>
			<thead><tr><th>First name</th><th>Email</th><th>Was planning</th><th>Travelling</th><th>Agreed on</th></tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?><tr><td colspan="5">Nobody yet.</td></tr><?php endif; ?>
			<?php foreach ( $rows as $r ) : ?>
				<tr data-gtp-contact>
					<td><?php echo esc_html( $r['name'] ); ?></td>
					<td><?php echo esc_html( $r['email'] ); ?></td>
					<td><?php echo esc_html( $names[ $r['slug'] ] ?? $r['slug'] ); ?></td>
					<td><?php echo esc_html( gtp_day( $r['fly'] ) ); ?></td>
					<td><?php echo esc_html( gtp_day( $r['made'] ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( $stopped ) : ?>
		<h2>Asked to stop</h2>
		<p>These people have left the list. If you copied the list into an email tool before the day shown, take them off there too.</p>
		<table class="widefat striped" style="max-width:600px" data-gtp-contacts-stopped>
			<thead><tr><th>Email</th><th>Asked to stop on</th></tr></thead>
			<tbody>
			<?php foreach ( $stopped as $email => $day ) : ?>
				<tr><td><?php echo esc_html( $email ); ?></td><td><?php echo esc_html( gtp_day( $day ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>

		<h2>For the site's privacy notice</h2>
		<p>Add this line to the privacy notice before the planner asks anyone:</p>
		<p><textarea class="large-text" rows="2" readonly data-gtp-contacts-privacy><?php echo esc_textarea( gtp_contacts_privacy_line() ); ?></textarea></p>
		<p class="description">A person's details can be found and deleted with WordPress's own Tools &rsaquo; Export Personal Data and Erase Personal Data. Removing the plugin deletes this list: download it first if you want to keep it.</p>
	</div>
	<?php
}
