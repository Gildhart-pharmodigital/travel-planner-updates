<?php
/**
 * [travel_guide country="thailand"]: the part of a country guide page that
 * changes.
 *
 * A guide page is the site's own: its writer gives the introduction, the
 * local angle and the questions people ask. This shortcode gives the rest,
 * from the same pack and the same settings as the planner, so it says what
 * the planner's card for that country says: the vaccines the guidance lists
 * for most travellers and for some trips, each at this pharmacy's price a
 * dose, how far ahead to start, the certificate and malaria facts, NaTHNaC's
 * outbreak notices for that country, and the booking. Each new version of
 * the plugin (each month's guidance) brings every guide up to date with
 * nobody touching it. It is drawn on the server, so it is in the page's own
 * HTML for search engines, and needs no script.
 *
 *   country   the country as the planner's address names it (?going=thailand)
 *   part      all (the default), vaccines, before or book: one piece, so the
 *             writer's own words can sit between them
 *   heading   the vaccines' heading ("Travel vaccines for Thailand")
 *   book      where its Book button goes, if not the settings' booking link
 *
 * A published page carrying it becomes that country's guide: the planner
 * links it ("Read our Thailand guide", and under the box) from the moment it
 * is published, found when the page is saved (its content, or Elementor's)
 * or first shown (a theme template). A guide named in the settings wins.
 * A guide shows what the planner shows: nothing to the public while the
 * planner is in preview.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_GUIDES_OPTION  = 'gtp_guide_pages';   // country slug => array( 'id' => post ID, 'how' => content|seen )
const GTP_PLANNER_OPTION = 'gtp_planner_page';  // the published page the planner is on

/** A country's file from the pack, or null. */
function gtp_country( $slug ) {
	$slug = (string) $slug;
	if ( ! preg_match( '/^[a-z0-9-]+$/', $slug ) ) { return null; }
	$d = gtp_data( 'countries/' . $slug );
	return $d ? $d : null;
}

/* ---- the words a card uses (assets/planner.js says the same) ---------------- */

/** A dose's price: "£56 a dose" for a course of more than one, a single dose at its price. Never a course's total. */
function gtp_price_text( $v, $vaccines ) {
	if ( 'not' === $v['status'] ) { return 'Not given here'; }
	if ( 'given' !== $v['status'] ) { return 'Ask us'; }
	if ( null === $v['price'] || '' === $v['price'] ) {
		$inside = '' !== (string) $v['included_in'] && isset( $vaccines[ $v['included_in'] ] ) ? $vaccines[ $v['included_in'] ] : null;
		if ( $inside && 'given' === $inside['status'] ) { return 'With the ' . lcfirst( $inside['name'] ) . ' booster'; }
		return 'Ask us';
	}
	return $v['doses'] > 1 ? gtp_money( $v['price'] ) . ' a dose' : gtp_money( $v['price'] );
}

function gtp_child_text( $v ) {
	if ( 'given' !== $v['status'] || null === $v['price'] || '' === $v['price'] || null === $v['child_price'] || '' === $v['child_price'] ) { return ''; }
	return gtp_money( $v['child_price'] ) . ( $v['doses'] > 1 ? ' a dose' : '' ) . ' for children';
}

function gtp_course_text( $v ) {
	return $v['doses'] > 1 ? $v['doses'] . ' doses' : 'Single dose';
}

/** A vaccine's name, linked to this site's page about it where there is one to link (gtp_vaccine_url()), as the card links it. */
function gtp_vaccine_name_html( $v ) {
	$name = esc_html( $v['name'] );
	if ( '' === (string) ( $v['url'] ?? '' ) ) { return $name; }
	return '<a class="gtp__vax-link" href="' . esc_url( $v['url'] ) . '" data-gtp-vax-link>' . $name . '</a>';
}

/** The pack's rows for a tier, each with what this pharmacy said of that vaccine. */
function gtp_guide_rows( $d, $tier ) {
	$vaccines = gtp_vaccines();
	$out      = array();
	foreach ( (array) ( $d['vaccines'][ $tier ] ?? array() ) as $r ) {
		if ( empty( $r['id'] ) || ! isset( $vaccines[ $r['id'] ] ) ) { continue; }
		$v     = $vaccines[ $r['id'] ];
		$out[] = $v + array( 'id' => (string) $r['id'], 'tier' => $tier, 'pack_note' => (string) ( $r['note'] ?? '' ) );
	}
	return $out;
}

/* ---- where a guide and the planner are ----------------------------------------- */

/** The published page being shown, or 0. */
function gtp_shown_page() {
	if ( ! function_exists( 'is_singular' ) || ! is_singular() ) { return 0; }
	$id = (int) get_queried_object_id();
	return $id && 'publish' === get_post_status( $id ) ? $id : 0;
}

/** The planner's page, learnt the first time the planner is shown on a published page; '' until then. */
function gtp_planner_page_url() {
	$id = (int) get_option( GTP_PLANNER_OPTION, 0 );
	return $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : '';
}

function gtp_planner_seen() {
	$id = gtp_shown_page();
	if ( ! $id || '' !== gtp_planner_page_url() ) { return; }
	update_option( GTP_PLANNER_OPTION, $id, false );
}

/** Every guide page found: country slug => id and how it was found. */
function gtp_guide_pages() {
	$d = get_option( GTP_GUIDES_OPTION, array() );
	return is_array( $d ) ? $d : array();
}

function gtp_guide_pages_save( $map ) {
	ksort( $map );
	update_option( GTP_GUIDES_OPTION, $map, false );
	/* The planner's page carries the guide links in its HTML: a cached copy would go on without the new one. */
	gtp_purge_pages( 'guides' );
}

/** The countries named by [travel_guide] in a page's text (its content, or Elementor's data, where quotes are escaped). */
function gtp_guide_countries_in( $text ) {
	$out = array();
	if ( preg_match_all( '/\[travel_guide\b([^\]]*)\]/', (string) $text, $m ) ) {
		foreach ( $m[1] as $attrs ) {
			if ( preg_match( '/country\s*=\s*\\\\?["\']?([a-z0-9-]+)/i', $attrs, $c ) && isset( gtp_country_names()[ strtolower( $c[1] ) ] ) ) {
				$out[] = strtolower( $c[1] );
			}
		}
	}
	return array_values( array_unique( $out ) );
}

/** A published page showing a country's guide becomes that country's guide, unless another published page already is. */
function gtp_guide_seen( $slug ) {
	$id = gtp_shown_page();
	if ( ! $id ) { return; }
	$map = gtp_guide_pages();
	$cur = $map[ $slug ] ?? null;
	if ( $cur && ( (int) $cur['id'] === $id || 'publish' === get_post_status( (int) $cur['id'] ) ) ) { return; }
	$map[ $slug ] = array( 'id' => $id, 'how' => 'seen' );
	gtp_guide_pages_save( $map );
}

/* A page saved: the guides its text carries are its, and one it no longer carries is not. */
add_action( 'save_post', function ( $post_id, $post = null ) {
	if ( ( function_exists( 'wp_is_post_revision' ) && wp_is_post_revision( $post_id ) ) || ( function_exists( 'wp_is_post_autosave' ) && wp_is_post_autosave( $post_id ) ) ) { return; }
	$post  = is_object( $post ) ? $post : get_post( $post_id );
	$text  = (string) ( $post->post_content ?? '' ) . "\n" . (string) get_post_meta( $post_id, '_elementor_data', true );
	$found = gtp_guide_countries_in( $text );
	$map   = gtp_guide_pages();
	$was   = $map;
	foreach ( $map as $slug => $e ) {
		if ( (int) $e['id'] === (int) $post_id && 'content' === ( $e['how'] ?? '' ) && ! in_array( $slug, $found, true ) ) { unset( $map[ $slug ] ); }
	}
	foreach ( $found as $slug ) {
		$cur = $map[ $slug ] ?? null;
		if ( $cur && (int) $cur['id'] !== (int) $post_id && 'publish' === get_post_status( (int) $cur['id'] ) ) { continue; }
		$map[ $slug ] = array( 'id' => (int) $post_id, 'how' => 'content' );
	}
	if ( $map !== $was ) { gtp_guide_pages_save( $map ); }
}, 10, 2 );

/* A guide published or taken down: the planner's cached page must follow. */
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( $new === $old || ( 'publish' !== $new && 'publish' !== $old ) || ! is_object( $post ) ) { return; }
	foreach ( gtp_guide_pages() as $e ) {
		if ( (int) $e['id'] === (int) $post->ID ) { gtp_purge_pages( 'guides' ); return; }
	}
}, 10, 3 );

/** Where a guide's Book button goes: its own, then the settings' link (an anchor is on the planner's page). */
function gtp_guide_book( $attr ) {
	$attr = trim( (string) $attr );
	if ( preg_match( '~^(#[A-Za-z0-9_-]+|/(?!/)\S*|https://\S+)$~', $attr ) ) { return $attr; }
	$book = (string) gtp_setting( 'booking_url' );
	if ( '' === $book || '#' !== $book[0] ) { return $book; }
	$page = gtp_planner_page_url();
	return '' !== $page && gtp_shown_page() !== (int) get_option( GTP_PLANNER_OPTION, 0 ) ? $page . $book : $book;
}

/* ---- the shortcode ------------------------------------------------------------- */

function gtp_guide_shortcode( $atts = array() ) {
	$a = shortcode_atts( array( 'country' => '', 'part' => 'all', 'heading' => '', 'book' => '', 'id' => '' ), $atts, 'travel_guide' );
	$slug  = strtolower( trim( (string) $a['country'] ) );
	$names = gtp_country_names();
	if ( ! isset( $names[ $slug ] ) ) {
		return function_exists( 'current_user_can' ) && current_user_can( 'edit_posts' )
			? '<p class="gtp-guide-problem" data-gtp-guide-problem>Travel guide: there is no country &ldquo;' . esc_html( $slug ) . '&rdquo;. Name it as the planner&rsquo;s address does, for example country="thailand" or country="sri-lanka".</p>'
			: '';
	}
	if ( ! gtp_visible() ) { return ''; }
	gtp_guide_seen( $slug );

	$part = in_array( $a['part'], array( 'all', 'vaccines', 'before', 'book' ), true ) ? $a['part'] : 'all';
	$name = $names[ $slug ];
	$d    = gtp_country( $slug );
	$id   = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $a['id'] );
	$id   = '' !== $id ? $id : 'travel-guide-' . $slug . ( 'all' === $part ? '' : '-' . $part );
	gtp_enqueue_style();

	$html = '';
	if ( 'all' === $part || 'vaccines' === $part ) { $html .= gtp_guide_vaccines_html( $slug, $name, $d, (string) $a['heading'], $id ); }
	if ( 'all' === $part || 'before' === $part ) { $html .= gtp_guide_before_html( $slug, $name, $d ); }
	if ( 'all' === $part || 'book' === $part ) { $html .= gtp_guide_book_html( $name, gtp_guide_book( $a['book'] ) ); }
	if ( ( 'all' === $part || 'vaccines' === $part ) && $d ) { $html .= gtp_guide_source_html( $name, $d ); }
	if ( '' === $html ) { return ''; }

	$preview = gtp_public() ? '' : '<p class="gtp__preview" role="status" data-gtp-preview><strong>Preview.</strong> ' . gtp_preview_words( 'this guide&rsquo;s vaccines and prices' ) . '</p>';
	return '<section class="gtp gtp-guide" id="' . esc_attr( $id ) . '" ' . gtp_style_attr() . ' data-gtp-guide="' . esc_attr( $slug ) . '" data-gtp-guide-part="' . esc_attr( $part ) . '">'
		. $preview . '<div class="gtp-guide__inner">' . $html . '</div></section>';
}
add_shortcode( 'travel_guide', 'gtp_guide_shortcode' );

function gtp_guide_vaccines_html( $slug, $name, $d, $heading, $id ) {
	$heading = '' !== trim( $heading ) ? trim( $heading ) : 'Travel vaccines for ' . $name;
	$out     = '<header class="gtp-guide__head"><h2 class="gtp-guide__heading" id="' . esc_attr( $id ) . '-heading">' . esc_html( $heading ) . '</h2>';
	if ( ! $d ) {
		/* A country the planner has no card for: what the planner says of it. */
		return $out . '<p class="gtp-guide__lead">We haven&rsquo;t read ' . esc_html( $name ) . '&rsquo;s guidance into the planner yet. Book a travel consultation and the pharmacist goes through what your trip needs, from the same guidance.</p></header>';
	}
	$checked = (string) ( $d['checked'] ?? '' );
	$out    .= '<p class="gtp-guide__checked" data-gtp-guide-checked>What the guidance recommends for ' . esc_html( $name ) . ' and what each vaccine costs here'
		. ( $checked ? ', checked against TravelHealthPro on ' . esc_html( gtp_day( $checked ) ) : '' ) . '.</p></header>';
	$vaccines = gtp_vaccines();
	foreach ( array( 'most' => 'Recommended for most travellers', 'some' => 'For some trips' ) as $tier => $title ) {
		$rows = gtp_guide_rows( $d, $tier );
		if ( ! $rows ) { continue; }
		$out .= '<div class="gtp-guide__group" data-gtp-guide-tier="' . $tier . '"><h3 class="gtp-guide__group-title">' . esc_html( $title ) . ' <span class="gtp-guide__count">' . count( $rows ) . '</span></h3><ul class="gtp-guide__list">';
		foreach ( $rows as $v ) {
			$child = gtp_child_text( $v );
			$start = is_array( $v['lead'] ) && ! empty( $v['lead']['text'] ) && 'not' !== $v['status'] ? 'Start ' . lcfirst( trim( (string) $v['lead']['text'] ) ) . ' you travel' : '';
			$out  .= '<li class="gtp-guide__vax" data-gtp-row="' . esc_attr( $v['id'] ) . '" data-fit="' . $tier . '" data-status="' . esc_attr( $v['status'] ) . '">'
				. '<div class="gtp-guide__vax-head"><h4 class="gtp-guide__vax-name">' . gtp_vaccine_name_html( $v ) . '</h4>'
				. '<p class="gtp-guide__price" data-gtp-price>' . esc_html( gtp_price_text( $v, $vaccines ) ) . '</p></div>'
				. '<p class="gtp-guide__note">' . esc_html( $v['pack_note'] ) . '</p>'
				. '<p class="gtp-guide__meta"><span class="gtp-guide__course">' . esc_html( gtp_course_text( $v ) ) . '</span>'
				. ( $start ? '<span class="gtp-guide__start" data-gtp-start>' . esc_html( $start ) . '</span>' : '' )
				. ( $child ? '<span class="gtp-guide__child" data-gtp-child>' . esc_html( $child ) . '</span>' : '' ) . '</p>'
				. ( '' !== $v['note'] ? '<p class="gtp-guide__where" data-gtp-where>' . esc_html( $v['note'] ) . '</p>' : '' )
				. '</li>';
		}
		$out .= '</ul></div>';
	}
	if ( ! empty( $d['also_listed'] ) ) {
		$out .= '<p class="gtp-guide__also">TravelHealthPro also lists ' . esc_html( implode( ', ', (array) $d['also_listed'] ) ) . ' for some travellers; ask us at your consultation.</p>';
	}
	$line = (string) gtp_setting( 'consultation_line' );
	$out .= '<p class="gtp__note gtp-guide__disclaimer" data-gtp-note>A starting point, not a quote. Which vaccines apply to you is settled at your consultation, and each price is for one dose.' . ( '' !== $line ? ' ' . esc_html( $line ) : '' ) . '</p>';
	return $out;
}

function gtp_guide_before_html( $slug, $name, $d ) {
	if ( ! $d ) { return ''; }
	$facts = array();
	foreach ( (array) ( $d['certificates'] ?? array() ) as $i => $line ) {
		if ( '' !== (string) $line ) { $facts[] = array( $i ? 'certificate-more' : 'certificate', esc_html( $line ) ); }
	}
	$listed = array();
	foreach ( array( 'most', 'some' ) as $tier ) { foreach ( (array) ( $d['vaccines'][ $tier ] ?? array() ) as $r ) { $listed[ $r['id'] ?? '' ] = true; } }
	if ( gtp_setting( 'yf_centre' ) && '' !== (string) gtp_setting( 'yf_line' ) && isset( $listed['yellow-fever'] ) ) {
		$facts[] = array( 'yf-centre', esc_html( gtp_setting( 'yf_line' ) ) );
	}
	if ( ! empty( $d['malaria']['line'] ) ) { $facts[] = array( 'malaria', esc_html( $d['malaria']['line'] ) ); }
	$seen = array();
	$named = array();
	foreach ( gtp_notices_current() as $n ) {
		if ( (string) $n['slug'] !== $slug ) { continue; }
		$k = strtolower( (string) $n['disease'] );
		if ( isset( $seen[ $k ] ) ) { continue; }
		$seen[ $k ] = true;
		$named[]    = esc_html( $n['disease'] . ' (' . gtp_day( $n['date'] ) . ')' );
	}
	if ( $named ) {
		$facts[] = array( 'notices', 'Outbreak notices from NaTHNaC: ' . implode( ', ', $named ) . '. We go through them at your consultation.'
			. ( ! empty( $d['source'] ) ? ' <a href="' . esc_url( $d['source'] ) . '" target="_blank" rel="noopener noreferrer">Read them on TravelHealthPro</a>' : '' ) );
	}
	if ( ! $facts ) { return ''; }
	$out = '<div class="gtp-guide__before" data-gtp-guide-before><h3 class="gtp-guide__group-title">Before you go to ' . esc_html( $name ) . '</h3><ul class="gtp__facts gtp-guide__facts" data-gtp-facts>';
	foreach ( $facts as $f ) { $out .= '<li data-gtp-fact="' . esc_attr( $f[0] ) . '"><span>' . $f[1] . '</span></li>'; }
	return $out . '</ul></div>';
}

function gtp_guide_book_html( $name, $book ) {
	$phone   = (string) gtp_setting( 'phone' );
	$planner = gtp_planner_page_url();
	$buttons = '';
	if ( '' !== $book ) { $buttons .= '<a class="gtp__button gtp__button--primary" href="' . esc_url( $book ) . '" data-gtp-book>Book a travel consultation</a>'; }
	if ( '' !== $phone ) { $buttons .= '<a class="gtp__button gtp__button--secondary" href="' . esc_attr( 'tel:' . preg_replace( '/\s+/', '', $phone ) ) . '" data-gtp-call>Call ' . esc_html( $phone ) . '</a>'; }
	if ( '' === $buttons ) { return ''; }
	return '<div class="gtp-guide__book" data-gtp-guide-book><h3 class="gtp-guide__book-title">Going to ' . esc_html( $name ) . '?</h3>'
		. '<p class="gtp-guide__book-line">Tell us your dates and route when you book, and the pharmacist goes through which of these your trip needs.</p>'
		. '<div class="gtp__actions gtp-guide__actions">' . $buttons . '</div>'
		. ( '' !== $planner && gtp_shown_page() !== (int) get_option( GTP_PLANNER_OPTION, 0 ) ? '<p class="gtp-guide__other"><a href="' . esc_url( $planner ) . '#trip-planner" data-gtp-guide-planner>Going somewhere else? Check any country in the trip planner</a></p>' : '' )
		. '</div>';
}

function gtp_guide_source_html( $name, $d ) {
	$licence = (string) ( gtp_pack()['licence'] ?? '' );
	return '<p class="gtp__source gtp-guide__source" data-gtp-source>Guidance from NaTHNaC&rsquo;s TravelHealthPro, written in our own words. '
		. ( ! empty( $d['source'] ) ? '<a href="' . esc_url( $d['source'] ) . '" target="_blank" rel="noopener noreferrer">Read their page for ' . esc_html( $name ) . '</a>. ' : '' )
		. esc_html( $licence ) . '</p>';
}
