<?php
/**
 * The licence: whether this site may show the planner to everyone, and take
 * Gildhart's updates.
 *
 * Gildhart gives each client or community member a key (tools/licence.php,
 * or the "Licence keys" workflow). It says who it is for, the site addresses
 * it works on, the plan and the last day it works, signed with Gildhart's
 * signing key; the plugin checks the signature with the public half below,
 * so no server is ever asked and nothing about the site is sent anywhere. A
 * key is not a secret: it works only on the addresses inside it.
 *
 * With a valid key the planner shows to everyone once "Show the planner to
 * everyone" is ticked, and each new version installs itself. Without one it
 * is a preview (only people who can edit the site see it) and no update is
 * offered. Nothing is taken away at once:
 *   - a site that was already public when this version arrived goes on
 *     showing to everyone for GTP_LICENCE_GRACE_DAYS, to add its key;
 *   - so does a site whose key has ended (from its last day) or been
 *     withdrawn (from the day the site learnt of it).
 * The screens say which, and until when.
 *
 * The key is read from the settings screen, else the theme's
 * gildhart-travel-planner.json ("licence"), else GTP_LICENCE_KEY in
 * wp-config.php. Withdrawn keys are the "revoked" list in Gildhart's updates
 * file, read with the update check.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_LICENCE_PUBLIC      = 'X6IpJdf0PPEKElrejVP47lRcol68k91pL7Wz8rGaPQY';  // Gildhart's public key: LICENCE_SEED's (php tools/licence.php public-key); the release checks it
const GTP_LICENCE_TEST_PUBLIC = 'sroInO7wI2NfRxBJSppPhgOkIIqAZT5NJlrIChrqjK0';  // the test harness's, which signs nothing real
const GTP_LICENCE_PREFIX      = 'GTP1-';
const GTP_LICENCE_GRACE_DAYS  = 30;
const GTP_LICENCE_GRACE       = 'gtp_licence_grace';    // the day a public site without a valid key was first seen (Y-m-d)
const GTP_LICENCE_REVOKED     = 'gtp_licence_revoked';  // the ids withdrawn, as the updates file last listed them

function gtp_unb64url( $s ) {
	$s = strtr( (string) $s, '-_', '+/' );
	$d = base64_decode( $s . str_repeat( '=', ( 4 - strlen( $s ) % 4 ) % 4 ), true );
	return false === $d ? '' : $d;
}

/** An address as a key names it: lower case, no scheme, path or port, no leading www. */
function gtp_licence_site_of( $s ) {
	$s = strtolower( trim( (string) $s ) );
	$s = preg_replace( '~^[a-z]+://~', '', $s );
	$s = preg_replace( '~[/:?#].*$~', '', $s );
	return (string) preg_replace( '~^www\.~', '', $s );
}

/** This site's address, as a key would name it. */
function gtp_licence_here() {
	return gtp_licence_site_of( home_url( '/' ) );
}

/** The key in force, and where it came from: settings, theme or config. */
function gtp_licence_key() {
	$k = (string) gtp_setting( 'licence', '' );
	if ( '' !== $k ) { return array( $k, 'settings' ); }
	$file = (string) ( gtp_site_file()['licence'] ?? '' );
	$file = preg_replace( '/[^A-Za-z0-9._-]/', '', $file );
	if ( '' !== $file ) { return array( $file, 'theme' ); }
	if ( defined( 'GTP_LICENCE_KEY' ) && '' !== trim( (string) GTP_LICENCE_KEY ) ) { return array( preg_replace( '/[^A-Za-z0-9._-]/', '', (string) GTP_LICENCE_KEY ), 'config' ); }
	return array( '', '' );
}

function gtp_licence_today() {
	return wp_date( 'Y-m-d', gtp_notices_now() );
}

/**
 * What the key says and whether it holds here:
 *   state  valid | missing | malformed | signature | site | expired | revoked
 * with who, plan, sites, expires ('' for no end), id, here and from.
 */
function gtp_licence( $fresh = false ) {
	static $cache = null;
	if ( null !== $cache && ! $fresh ) { return $cache; }
	list( $key, $from ) = gtp_licence_key();
	$out = array( 'state' => 'missing', 'id' => '', 'who' => '', 'plan' => '', 'sites' => array(), 'expires' => '', 'here' => gtp_licence_here(), 'from' => $from );
	if ( '' === $key ) { return $cache = gtp_licence_settle( $out ); }
	$out['state'] = 'malformed';
	if ( 0 !== strpos( $key, GTP_LICENCE_PREFIX ) || 1 !== substr_count( $key, '.' ) ) { return $cache = gtp_licence_settle( $out ); }
	list( $p, $s ) = explode( '.', substr( $key, strlen( GTP_LICENCE_PREFIX ) ) );
	$payload = gtp_unb64url( $p );
	$sig     = gtp_unb64url( $s );
	$data    = json_decode( $payload, true );
	if ( ! is_array( $data ) || 1 !== ( $data['v'] ?? null ) ) { return $cache = gtp_licence_settle( $out ); }
	$pub = gtp_unb64url( defined( 'GTP_HARNESS' ) && GTP_HARNESS ? GTP_LICENCE_TEST_PUBLIC : GTP_LICENCE_PUBLIC );
	$ok  = false;
	if ( 32 === strlen( $pub ) && 64 === strlen( $sig ) && function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
		try { $ok = sodium_crypto_sign_verify_detached( $sig, $payload, $pub ); } catch ( Exception $e ) { $ok = false; }
	}
	if ( ! $ok ) { $out['state'] = 'signature'; return $cache = gtp_licence_settle( $out ); }
	$out = array_merge( $out, array(
		'id'      => preg_match( '/^[0-9a-f]{8}$/', (string) ( $data['id'] ?? '' ) ) ? (string) $data['id'] : '',
		'who'     => (string) ( $data['who'] ?? '' ),
		'plan'    => 'member' === ( $data['plan'] ?? '' ) ? 'member' : 'client',
		'sites'   => array_values( array_map( 'gtp_licence_site_of', (array) ( $data['sites'] ?? array() ) ) ),
		'expires' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $data['exp'] ?? '' ) ) ? (string) $data['exp'] : '',
	) );
	$here  = $out['here'];
	$fits  = false;
	foreach ( $out['sites'] as $site ) {
		if ( $site === $here || ( 0 === strpos( $site, '*.' ) && ( substr( $site, 2 ) === $here || substr( $here, -( strlen( $site ) - 1 ) ) === substr( $site, 1 ) ) ) ) { $fits = true; }
	}
	if ( ! $fits ) { $out['state'] = 'site'; }
	elseif ( '' !== $out['expires'] && gtp_licence_today() > $out['expires'] ) { $out['state'] = 'expired'; }
	elseif ( '' !== $out['id'] && in_array( $out['id'], (array) get_option( GTP_LICENCE_REVOKED, array() ), true ) ) { $out['state'] = 'revoked'; }
	else { $out['state'] = 'valid'; }
	return $cache = gtp_licence_settle( $out );
}

/** A valid key ends any grace; a key just found withdrawn starts one. */
function gtp_licence_settle( $l ) {
	$grace = (string) get_option( GTP_LICENCE_GRACE, '' );
	if ( 'valid' === $l['state'] && '' !== $grace ) { delete_option( GTP_LICENCE_GRACE ); }
	if ( 'revoked' === $l['state'] && '' === $grace ) { update_option( GTP_LICENCE_GRACE, gtp_licence_today(), false ); }
	return $l;
}

function gtp_licence_ok() {
	return 'valid' === gtp_licence()['state'];
}

/** The last day the planner may still show to everyone without a valid key, or ''. */
function gtp_licence_grace_until() {
	$l = gtp_licence();
	if ( 'valid' === $l['state'] ) { return ''; }
	$from = 'expired' === $l['state'] ? $l['expires'] : (string) get_option( GTP_LICENCE_GRACE, '' );
	$t    = $from ? strtotime( $from . ' 12:00:00 UTC' ) : false;
	return $t ? gmdate( 'Y-m-d', $t + GTP_LICENCE_GRACE_DAYS * DAY_IN_SECONDS ) : '';
}

/** Whether the licence lets the planner show to everyone today: a valid key, or a grace that has not run out. */
function gtp_licence_public() {
	if ( gtp_licence_ok() ) { return true; }
	$until = gtp_licence_grace_until();
	return '' !== $until && gtp_licence_today() <= $until;
}

/*
 * A site that was already showing the planner to everyone when this version
 * arrived keeps showing it for the grace, to add its key. A new install has
 * no version seen, and starts in preview like any other. This runs before
 * cache.php's own first-run hook records the new version.
 */
add_action( 'init', function () {
	$seen = (string) get_option( GTP_VERSION_OPTION, '' );
	if ( '' === $seen || version_compare( $seen, '1.5.0', '>=' ) ) { return; }
	if ( gtp_setting( 'enabled' ) && ! gtp_licence_ok() && '' === (string) get_option( GTP_LICENCE_GRACE, '' ) ) {
		update_option( GTP_LICENCE_GRACE, gtp_licence_today(), false );
	}
}, 5 );

/** The withdrawn keys, from the updates file. */
function gtp_licence_revoked_seen( $ids ) {
	$ids = array_values( array_filter( (array) $ids, function ( $id ) { return is_string( $id ) && preg_match( '/^[0-9a-f]{8}$/', $id ); } ) );
	sort( $ids );
	if ( $ids !== (array) get_option( GTP_LICENCE_REVOKED, array() ) ) { update_option( GTP_LICENCE_REVOKED, $ids, false ); }
	gtp_licence( true );
}

/** In words, for the settings screen. */
function gtp_licence_words() {
	$l     = gtp_licence();
	$until = gtp_licence_grace_until();
	$sites = implode( ', ', $l['sites'] );
	$grace = '' !== $until ? ( gtp_licence_today() <= $until
		? ' Until ' . gtp_day( $until ) . ' the planner still shows to everyone; after that it goes back to preview.'
		: ' The planner is back in preview: only people who can edit the site see it.' ) : '';
	$no    = ' The planner shows only to people who can edit the site, and takes no updates.';
	switch ( $l['state'] ) {
		case 'valid':
			return 'Licensed to ' . $l['who'] . ' (' . ( 'member' === $l['plan'] ? 'community member' : 'Gildhart client' ) . ') for ' . $sites . ', '
				. ( '' !== $l['expires'] ? 'until ' . gtp_day( $l['expires'] ) : 'with no end date' ) . '. Each new version installs itself.';
		case 'missing':
			return 'No licence key yet. Paste the key Gildhart sent you.' . ( $grace ?: $no );
		case 'malformed':
			return 'That is not a Travel Planner licence key: they start GTP1-. Paste it again, all of it.' . ( $grace ?: $no );
		case 'signature':
			return 'That key was not issued by Gildhart, or has been changed since.' . ( $grace ?: $no );
		case 'site':
			return 'That key is for ' . $sites . ', not this site (' . $l['here'] . '). Ask Gildhart for a key for this address.' . ( $grace ?: $no );
		case 'expired':
			return 'This key ended on ' . gtp_day( $l['expires'] ) . '. Ask Gildhart for a new one.' . $grace;
		case 'revoked':
			return 'This key has been withdrawn by Gildhart.' . $grace;
	}
	return '';
}

/* On the dashboard, the plugins screen and the plugin's own: a site showing the planner without a valid key is told, once a screen. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) || gtp_licence_ok() || ! gtp_setting( 'enabled' ) ) { return; }
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$id     = $screen ? (string) $screen->id : '';
	if ( '' !== $id && ! in_array( $id, array( 'dashboard', 'plugins' ), true ) && false === strpos( $id, 'gtp-' ) ) { return; }
	echo '<div class="notice notice-warning" data-gtp-licence-notice><p><strong>Travel Planner:</strong> ' . esc_html( gtp_licence_words() )
		. ' <a href="' . esc_url( admin_url( 'admin.php?page=gtp-settings' ) ) . '">Travel Planner &rsaquo; Settings</a></p></div>';
} );
