<?php
/**
 * Reminders: "not booking today? We'll remind you when it's time."
 *
 * A visitor who gives a flight date more than GTP_REMIND_WEEKS weeks away is
 * looking ahead, and a travel consultation is most often lost because they
 * come back too late. So the card offers a reminder for the day
 * GTP_REMIND_WEEKS weeks before they fly:
 *
 *   - in their own calendar: one event, as a calendar file or a Google
 *     Calendar link. Nothing about them is asked for or kept: the address
 *     carries the country and the flight date, and the site only counts that
 *     a reminder was added that month.
 *   - by email, only where the pharmacy has switched it on (it keeps an email
 *     address, so the site's privacy notice must say so first). The visitor
 *     gives an address and ticks their agreement; they are emailed at once
 *     with what they asked for and a link that cancels it; they are emailed
 *     once on the day; the address and the trip are then deleted. Unless
 *     they also ticked the second box, to be kept in touch with: then they
 *     are kept on the pharmacy's contacts list (includes/contacts.php).
 *
 * When: the NHS says to "get advice from a travel health professional at
 * least 4 to 6 weeks before you travel" (nhs.uk/vaccinations/travel-vaccinations,
 * page last reviewed 30 April 2026; read 13 November 2026). Eight weeks
 * before leaves two to get an appointment.
 *
 * What it says: a travel consultation, and never a vaccine. A reminder is an
 * advertisement, and the UK's advertising code does not allow a
 * prescription-only medicine, which a vaccine is, to be advertised to the
 * public (CAP Code, rule 12.12; the ASA's advice is to "promote the
 * consultation itself, rather than the product").
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_REMIND_WEEKS     = 8;
const GTP_REMIND_ADVICE    = 'The NHS advises getting travel health advice at least 4 to 6 weeks before you travel.';
const GTP_REMINDERS_OPTION = 'gtp_reminders';        // token => email, slug, fly, on, made (and name, where one was given): only while an email reminder waits
const GTP_REMINDER_COUNTS  = 'gtp_reminder_counts';  // 'YYYY-MM' => calendar, email, sent, cancelled, kept, stopped: how many, and nothing else
const GTP_REMINDERS_MAX    = 2000;                   // email reminders waiting at once
const GTP_REMINDERS_HOUR   = 30;                     // email reminders asked for in an hour, the whole site: a form cannot be made to send mail without end
const GTP_REMINDERS_KEY    = 'gtp_reminders_hour';

/** Whether the card offers a reminder at all: wherever the planner is shown, unless the settings say not. */
function gtp_reminders_on() {
	return (bool) gtp_setting( 'reminders', true ) && gtp_visible();
}

/** Whether a reminder by email is offered: only by a pharmacy that switched it on, and only once the planner is public. */
function gtp_reminders_email_on() {
	return (bool) gtp_setting( 'reminders', true ) && (bool) gtp_setting( 'remind_email', false ) && gtp_public();
}

/**
 * A trip a reminder can be set for: a country the planner knows and a flight
 * far enough ahead that the reminder's day has not come. Null otherwise: a
 * flight inside the weeks is a booking to make now, not a reminder.
 */
function gtp_reminder_trip( $slug, $fly ) {
	if ( ! is_string( $slug ) || ! is_string( $fly ) ) { return null; }
	$slug  = strtolower( trim( (string) $slug ) );
	$fly   = trim( (string) $fly );
	$names = gtp_country_names();
	if ( ! isset( $names[ $slug ] ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fly ) ) { return null; }
	$t = strtotime( $fly . ' 12:00:00 UTC' );
	if ( ! $t || gmdate( 'Y-m-d', $t ) !== $fly ) { return null; }
	$on    = gmdate( 'Y-m-d', $t - GTP_REMIND_WEEKS * 7 * DAY_IN_SECONDS );
	$today = wp_date( 'Y-m-d', gtp_notices_now() );
	if ( $on <= $today || $t > gtp_notices_now() + 730 * DAY_IN_SECONDS ) { return null; }
	return array( 'slug' => $slug, 'name' => $names[ $slug ], 'fly' => $fly, 'on' => $on );
}

/** Where a reminder sends its reader: the booking, and the planner opened on their country. Whole addresses, for a calendar or an email. */
function gtp_reminder_links( $slug ) {
	$page = gtp_planner_page_url();
	$book = (string) gtp_setting( 'booking_url' );
	if ( '' === $book ) { $to = $page; }
	elseif ( '#' === $book[0] ) { $to = '' !== $page ? $page . $book : ''; }
	elseif ( '/' === $book[0] ) { $to = home_url( $book ); }
	else { $to = $book; }
	return array(
		'book'    => '' !== $to ? $to : home_url( '/' ),
		'planner' => '' !== $page ? add_query_arg( array( 'going' => $slug ), $page ) . '#trip-planner' : '',
	);
}

/** What a reminder says, in a calendar or an email: its title, its paragraphs and where it leads. */
function gtp_reminder_words( $trip ) {
	$links = gtp_reminder_links( $trip['slug'] );
	$name  = (string) gtp_setting( 'pharmacy' );
	$phone = (string) gtp_setting( 'phone' );
	$paras = array(
		'You\'re flying to ' . $trip['name'] . ' on ' . gtp_day( $trip['fly'] ) . '.',
		GTP_REMIND_ADVICE . ' So this is a good week to book your travel consultation' . ( '' !== $name ? ' at ' . $name : '' ) . '.',
		'Book: ' . $links['book'],
	);
	if ( '' !== $links['planner'] ) { $paras[] = 'What the UK guidance lists for ' . $trip['name'] . ': ' . $links['planner']; }
	if ( '' !== $phone ) { $paras[] = 'Or call ' . $phone . '.'; }
	return array( 'title' => 'Book your travel consultation for ' . $trip['name'], 'paragraphs' => $paras, 'book' => $links['book'], 'planner' => $links['planner'] );
}

/* ---- how many, by month ---------------------------------------------------------- */

function gtp_reminder_counts() {
	$d = get_option( GTP_REMINDER_COUNTS, array() );
	return is_array( $d ) ? $d : array();
}

/** One more of a kind this month (calendar, email, sent, cancelled). A number, and nothing about anyone. */
function gtp_reminder_count( $what ) {
	$all   = gtp_reminder_counts();
	$month = gtp_lookups_month();
	if ( ! isset( $all[ $month ] ) || ! is_array( $all[ $month ] ) ) { $all[ $month ] = array(); }
	$all[ $month ][ $what ] = (int) ( $all[ $month ][ $what ] ?? 0 ) + 1;
	ksort( $all );
	update_option( GTP_REMINDER_COUNTS, array_slice( $all, -GTP_LOOKUPS_KEEP, null, true ), false );
}

/* ---- the calendar: nothing kept ---------------------------------------------------- */

/** The address a calendar reminder is asked from: the site's front page, with the trip in its query. */
function gtp_calendar_url() {
	return (string) apply_filters( 'gtp_calendar_url', home_url( '/' ) );
}

/** A line of a calendar file: its commas, semicolons and line breaks said the way the format says them. */
function gtp_ics_text( $s ) {
	return str_replace( array( '\\', ';', ',', "\r\n", "\n" ), array( '\\\\', '\;', '\,', '\n', '\n' ), (string) $s );
}

/** A calendar file's line, folded at 75 bytes as the format asks, never through the middle of a letter. */
function gtp_ics_fold( $line ) {
	$out = '';
	while ( strlen( $line ) > 73 ) {
		$cut = 73;
		while ( $cut > 1 && 0x80 === ( ord( $line[ $cut ] ) & 0xC0 ) ) { $cut--; }
		$out .= substr( $line, 0, $cut ) . "\r\n ";
		$line = substr( $line, $cut );
	}
	return $out . $line;
}

/** The reminder as a calendar file: one all-day event on the reminder's day, with an alert at nine that morning. */
function gtp_calendar_ics( $trip ) {
	$w     = gtp_reminder_words( $trip );
	$next  = gmdate( 'Ymd', strtotime( $trip['on'] . ' 12:00:00 UTC' ) + DAY_IN_SECONDS );
	$lines = array(
		'BEGIN:VCALENDAR',
		'VERSION:2.0',
		'PRODID:-//Gildhart//Travel Planner//EN',
		'CALSCALE:GREGORIAN',
		'METHOD:PUBLISH',
		'BEGIN:VEVENT',
		'UID:gtp-' . $trip['slug'] . '-' . $trip['fly'] . '@' . (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ),
		'DTSTAMP:' . gmdate( 'Ymd\THis\Z', gtp_notices_now() ),
		'DTSTART;VALUE=DATE:' . str_replace( '-', '', $trip['on'] ),
		'DTEND;VALUE=DATE:' . $next,
		'SUMMARY:' . gtp_ics_text( $w['title'] ),
		'DESCRIPTION:' . gtp_ics_text( implode( "\n\n", $w['paragraphs'] ) ),
		'URL:' . $w['book'],
		'TRANSP:TRANSPARENT',
		'BEGIN:VALARM',
		'ACTION:DISPLAY',
		'DESCRIPTION:' . gtp_ics_text( $w['title'] ),
		'TRIGGER:PT9H',
		'END:VALARM',
		'END:VEVENT',
		'END:VCALENDAR',
	);
	return implode( "\r\n", array_map( 'gtp_ics_fold', $lines ) ) . "\r\n";
}

/** The same reminder as a link that opens Google Calendar with the event filled in. */
function gtp_calendar_google( $trip ) {
	$w    = gtp_reminder_words( $trip );
	$next = gmdate( 'Ymd', strtotime( $trip['on'] . ' 12:00:00 UTC' ) + DAY_IN_SECONDS );
	return 'https://calendar.google.com/calendar/render?action=TEMPLATE'
		. '&text=' . rawurlencode( $w['title'] )
		. '&dates=' . str_replace( '-', '', $trip['on'] ) . '/' . $next
		. '&details=' . rawurlencode( implode( "\n\n", $w['paragraphs'] ) );
}

/* ?gtp_calendar=<country>&fly=<date>[&to=google] on the front page: the calendar file, or Google Calendar. */
add_action( 'init', function () {
	if ( ! isset( $_GET['gtp_calendar'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification -- a read: it changes nothing but a count
	$trip = gtp_reminders_on() ? gtp_reminder_trip( wp_unslash( $_GET['gtp_calendar'] ), wp_unslash( $_GET['fly'] ?? '' ) ) : null; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- checked against the countries and a date's shape
	nocache_headers();
	header( 'X-Robots-Tag: noindex' );
	if ( ! $trip ) {
		status_header( 404 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo 'There is no reminder to add for that trip.';
		exit;
	}
	/* Counted as a visitor's: not a crawler's, not an editor's trying it out, and never in preview. */
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- only matched against a pattern
	if ( gtp_public() && ! ( function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) && gtp_lookups_from_here( $ua, home_url( '/' ), '' ) ) {
		gtp_reminder_count( 'calendar' );
	}
	if ( 'google' === ( $_GET['to'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_redirect( gtp_calendar_google( $trip ), 302 ); // phpcs:ignore WordPress.Security.SafeRedirect -- Google Calendar's own address, built here
		exit;
	}
	header( 'Content-Type: text/calendar; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="travel-consultation-' . $trip['slug'] . '.ics"' );
	echo gtp_calendar_ics( $trip ); // phpcs:ignore WordPress.Security.EscapeOutput -- a calendar file, escaped as that format asks
	exit;
}, 20 );

/* ---- by email: kept until sent, then deleted ------------------------------------------ */

/** The email reminders waiting to be sent: token => email, slug, fly, on, made. */
function gtp_reminders() {
	$d = get_option( GTP_REMINDERS_OPTION, array() );
	return is_array( $d ) ? $d : array();
}

function gtp_reminders_save( $rows ) {
	if ( $rows ) { update_option( GTP_REMINDERS_OPTION, $rows, false ); } else { delete_option( GTP_REMINDERS_OPTION ); }
}

/** One line for the site's privacy notice, saying exactly what an email reminder keeps and for how long. */
function gtp_reminders_privacy_line() {
	$what = gtp_setting( 'remind_keep', true ) ? 'your email address, your first name if you give one, the country and your travel date' : 'your email address, the country and your travel date';
	return 'If you ask our travel planner for an email reminder, we keep ' . $what . ' until the reminder is sent or you cancel it, and then delete them. We email you once to confirm and once to remind you.';
}

/** What the visitor agrees to, word for word as the card shows it: {on}, {country} and {pharmacy} are filled in there. */
function gtp_reminders_consent_words() {
	/* Where a second box asks to keep in touch, this one must not promise a deletion the second undoes. */
	if ( gtp_contacts_on() ) {
		return 'Email me now to confirm, and once on {on}, to remind me to book a travel consultation for {country}. {pharmacy} keeps my first name, my email address and this trip until that reminder is sent, and then deletes them unless I tick the next box.';
	}
	return 'Email me now to confirm, and once on {on}, to remind me to book a travel consultation for {country}. {pharmacy} keeps my email address and this trip until that reminder is sent, then deletes them.';
}

/** The link that cancels a reminder and deletes what it kept. */
function gtp_reminder_cancel_url( $token ) {
	return add_query_arg( array( 'gtp_reminder_cancel' => $token ), gtp_calendar_url() );
}

/**
 * Keep an email reminder and say so by email. Returns 'set', 'kept' when
 * they are also on the contacts list (they ticked the second box, $keep), or
 * 'busy' when the site has taken as many as it will for now. The same address
 * asking again for the same trip is told 'set' and nothing more is kept or
 * sent, unless this time they asked to be kept in touch with.
 */
function gtp_reminders_add( $email, $trip, $name = '', $keep = false ) {
	$rows = gtp_reminders();
	$dup  = false;
	foreach ( $rows as $r ) {
		if ( strtolower( (string) $r['email'] ) === strtolower( $email ) && $r['slug'] === $trip['slug'] && $r['fly'] === $trip['fly'] ) { $dup = true; break; }
	}
	if ( ! $dup ) {
		$asked = (int) get_transient( GTP_REMINDERS_KEY );
		if ( $asked >= GTP_REMINDERS_HOUR || count( $rows ) >= GTP_REMINDERS_MAX ) { return 'busy'; }
		set_transient( GTP_REMINDERS_KEY, $asked + 1, HOUR_IN_SECONDS );
	}
	/* The second box, ticked: they go on the contacts list, and every email to them carries the way off it. */
	$was      = $keep ? gtp_contact_of( $email ) : null;
	$stop     = $keep ? gtp_contacts_add( $email, $name, $trip ) : '';
	$pharmacy = (string) gtp_setting( 'pharmacy' );
	$hello    = '' !== $name ? 'Hello ' . $name . ",\n\n" : '';
	$kept     = '' !== $stop ? 'You also asked us to email you travel health news and offers. We keep your first name, your email address and this trip for that, until you unsubscribe: ' . gtp_contact_stop_url( $stop ) . "\n\n" : '';
	if ( $dup ) {
		if ( '' !== $stop && ! $was ) {
			wp_mail( $email, 'You asked to hear from ' . ( '' !== $pharmacy ? $pharmacy : 'us' ), $hello . $kept . $pharmacy );
		}
		return '' !== $stop ? 'kept' : 'set';
	}
	$token          = bin2hex( random_bytes( 16 ) );
	$rows[ $token ] = array( 'email' => $email, 'slug' => $trip['slug'], 'fly' => $trip['fly'], 'on' => $trip['on'], 'made' => wp_date( 'Y-m-d', gtp_notices_now() ) );
	if ( '' !== $name ) { $rows[ $token ]['name'] = $name; }
	gtp_reminders_save( $rows );
	gtp_reminder_count( 'email' );
	$w = gtp_reminder_words( $trip );
	wp_mail(
		$email,
		'Your reminder is set: travel consultation for ' . $trip['name'],
		$hello
		. 'You asked ' . ( '' !== $pharmacy ? $pharmacy : 'us' ) . ' to remind you to book your travel consultation for ' . $trip['name'] . ' (flying ' . gtp_day( $trip['fly'] ) . ").\n\n"
		. 'We\'ll email you once, on ' . gtp_day( $trip['on'] )
		. ( '' !== $stop ? '.' : ', and then delete ' . ( '' !== $name ? 'your first name, ' : '' ) . 'your email address and your trip from our records.' ) . "\n\n"
		. $kept
		. 'Ready sooner? Book here: ' . $w['book'] . "\n\n"
		. ( '' !== $stop
			? 'Changed your mind about the reminder? Cancel it: ' . gtp_reminder_cancel_url( $token ) . "\n\n"
				. 'Didn\'t ask for any of this? Delete everything we hold about you: ' . gtp_contact_stop_url( $stop, true )
			: 'Didn\'t ask for this, or changed your mind? Cancel the reminder and delete your details now: ' . gtp_reminder_cancel_url( $token ) )
		. "\n\n" . $pharmacy
	);
	return '' !== $stop ? 'kept' : 'set';
}

/** The answer to gtp/v1/remind: whether the reminder was set, and if not, which thing to put right. */
function gtp_reminders_rest_ask( $request ) {
	$say = function ( $ok, $why = '', $kept = false ) {
		$r = new WP_REST_Response( $ok ? array( 'ok' => true, 'kept' => $kept ) : array( 'ok' => false, 'why' => $why ), 200 );
		$r->header( 'Cache-Control', 'no-store' );
		return $r;
	};
	if ( ! gtp_reminders_email_on() ) { return $say( false, 'off' ); }
	/* A script, a crawler, another site, or the box no person can see filled in: told it worked, and nothing is kept or sent. */
	if ( ! gtp_lookups_from_here( $request->get_header( 'user_agent' ), $request->get_header( 'origin' ), $request->get_header( 'referer' ) )
		|| '' !== trim( (string) $request->get_param( 'website' ) ) ) { return $say( true ); }
	$trip = gtp_reminder_trip( $request->get_param( 'c' ), $request->get_param( 'fly' ) );
	if ( ! $trip ) { return $say( false, 'trip' ); }
	$email = $request->get_param( 'email' );
	$email = is_string( $email ) ? trim( $email ) : '';
	if ( strlen( $email ) > 190 || ! is_email( $email ) ) { return $say( false, 'email' ); }
	/* Their agreement is the only ground for keeping the address: without the tick, nothing is kept. */
	if ( '1' !== (string) $request->get_param( 'agree' ) ) { return $say( false, 'agree' ); }
	/* The second box is its own agreement: only its own tick puts anyone on the contacts list, and only where the pharmacy asks. */
	$keep = gtp_contacts_on() && '1' === (string) $request->get_param( 'keep' );
	$name = gtp_contacts_on() ? gtp_contact_name( $request->get_param( 'name' ) ) : '';
	$did  = gtp_reminders_add( $email, $trip, $name, $keep );
	return 'busy' === $did ? $say( false, 'busy' ) : $say( true, '', 'kept' === $did );
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'gtp/v1', '/remind', array(
		'methods'             => 'POST',
		'callback'            => 'gtp_reminders_rest_ask',
		'permission_callback' => '__return_true',
	) );
} );

/**
 * The day's reminders: each one due is sent once and deleted. One that could
 * not be sent waits for tomorrow; one whose flight has gone is deleted
 * unsent; and with email reminders switched off, everything kept is deleted.
 * Returns how many were sent.
 */
function gtp_reminders_send() {
	$rows = gtp_reminders();
	if ( ! $rows ) { return 0; }
	if ( ! gtp_setting( 'remind_email', false ) || ! gtp_setting( 'reminders', true ) ) { gtp_reminders_save( array() ); return 0; }
	$today = wp_date( 'Y-m-d', gtp_notices_now() );
	$names = gtp_country_names();
	$name  = (string) gtp_setting( 'pharmacy' );
	$sent  = 0;
	foreach ( $rows as $token => $r ) {
		if ( (string) $r['fly'] <= $today || ! isset( $names[ $r['slug'] ] ) ) { unset( $rows[ $token ] ); continue; }
		if ( (string) $r['on'] > $today || ! gtp_public() ) { continue; }
		$trip = array( 'slug' => $r['slug'], 'name' => $names[ $r['slug'] ], 'fly' => $r['fly'], 'on' => $r['on'] );
		$w    = gtp_reminder_words( $trip );
		$who  = (string) ( $r['name'] ?? '' );
		$c    = gtp_contact_of( $r['email'] );
		$ok   = wp_mail(
			(string) $r['email'],
			'Time to book your travel consultation for ' . $trip['name'],
			( '' !== $who ? 'Hello ' . $who . ",\n\n" : '' )
			. "You asked us to remind you.\n\n" . implode( "\n\n", $w['paragraphs'] ) . "\n\n"
			. ( $c
				? 'This is the only reminder. You also asked us to email you travel health news and offers: to stop that and be taken off our list, ' . gtp_contact_stop_url( (string) $c['token'] )
				: 'This is the only reminder. Your ' . ( '' !== $who ? 'first name, your ' : '' ) . 'email address and your trip have now been deleted from our records.' )
			. "\n\n" . $name
		);
		if ( ! $ok ) { continue; }
		unset( $rows[ $token ] );
		$sent++;
		gtp_reminder_count( 'sent' );
	}
	gtp_reminders_save( $rows );
	return $sent;
}
add_action( GTP_NOTICES_HOOK, 'gtp_reminders_send', 30 );

/**
 * Whether a link from an email was confirmed: its page's button pressed.
 * Opening the link alone only asks. A mail service opens every link in an
 * email to check it before its reader sees it, so a link that acted when
 * opened would cancel a reminder, or take someone off a list, by itself.
 */
function gtp_link_confirmed() {
	return 'POST' === strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) && ! empty( $_POST['gtp_confirm'] ); // phpcs:ignore WordPress.Security.NonceVerification -- the link's own key is what is checked
}

/** The page such a link opens: what it will do, and the button that does it. */
function gtp_link_ask( $title, $question, $button ) {
	nocache_headers();
	header( 'X-Robots-Tag: noindex' );
	wp_die(
		'<p>' . esc_html( $question ) . '</p>'
		. '<form method="post"><input type="hidden" name="gtp_confirm" value="1"><p><button type="submit" class="button button-large" data-gtp-confirm>' . esc_html( $button ) . '</button></p></form>',
		esc_html( $title ),
		array( 'response' => 200 )
	);
}

/* ?gtp_reminder_cancel=<token>: the page asks; its button forgets the reminder, and the page says so. */
add_action( 'init', function () {
	if ( ! isset( $_GET['gtp_reminder_cancel'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification -- the token is the key: only the email it was sent to carries it
	$token = preg_replace( '/[^0-9a-f]/', '', (string) wp_unslash( $_GET['gtp_reminder_cancel'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$rows  = gtp_reminders();
	$had   = '' !== $token && isset( $rows[ $token ] );
	$c     = $had ? gtp_contact_of( $rows[ $token ]['email'] ) : null;
	if ( $had && ! gtp_link_confirmed() ) {
		gtp_link_ask( 'Travel reminder', 'Cancel your reminder to book a travel consultation, and delete the details kept for it?', 'Yes, cancel my reminder' );
	}
	if ( $had ) {
		unset( $rows[ $token ] );
		gtp_reminders_save( $rows );
		gtp_reminder_count( 'cancelled' );
	}
	nocache_headers();
	/* Someone on the contacts list is told they still are, and how to leave it: cancelling a reminder is not that. */
	if ( $c ) {
		wp_die(
			esc_html( 'Your reminder is cancelled. You are still on our list for travel health news and offers.' )
			. ' <a href="' . esc_url( gtp_contact_stop_url( (string) $c['token'] ) ) . '">' . esc_html( 'Leave that list too' ) . '</a>',
			'Travel reminder',
			array( 'response' => 200 )
		);
	}
	wp_die(
		esc_html( $had
			? 'Your reminder is cancelled, and your email address and trip have been deleted.'
			: 'That reminder is no longer kept: it was sent or cancelled already, and nothing of yours is held.' ),
		'Travel reminder',
		array( 'response' => 200 )
	);
}, 20 );

/* WordPress's own privacy tools (Tools > Export Personal Data, Erase Personal Data) find and delete a person's reminder. */
function gtp_reminders_export( $email, $page = 1 ) {
	$names = gtp_country_names();
	$items = array();
	foreach ( gtp_reminders() as $token => $r ) {
		if ( strtolower( (string) $r['email'] ) !== strtolower( trim( (string) $email ) ) ) { continue; }
		$items[] = array(
			'group_id'    => 'gtp-reminders',
			'group_label' => 'Travel Planner reminders',
			'item_id'     => 'gtp-reminder-' . substr( (string) $token, 0, 8 ),
			'data'        => array(
				array( 'name' => 'First name', 'value' => (string) ( $r['name'] ?? '' ) ),
				array( 'name' => 'Email address', 'value' => (string) $r['email'] ),
				array( 'name' => 'Country', 'value' => (string) ( $names[ $r['slug'] ] ?? $r['slug'] ) ),
				array( 'name' => 'Travel date', 'value' => (string) $r['fly'] ),
				array( 'name' => 'Reminder to be sent on', 'value' => (string) $r['on'] ),
				array( 'name' => 'Asked for on', 'value' => (string) $r['made'] ),
			),
		);
	}
	return array( 'data' => $items, 'done' => true );
}

function gtp_reminders_erase( $email, $page = 1 ) {
	$rows = gtp_reminders();
	$gone = 0;
	foreach ( $rows as $token => $r ) {
		if ( strtolower( (string) $r['email'] ) === strtolower( trim( (string) $email ) ) ) { unset( $rows[ $token ] ); $gone++; }
	}
	if ( $gone ) { gtp_reminders_save( $rows ); }
	return array( 'items_removed' => $gone, 'items_retained' => false, 'messages' => array(), 'done' => true );
}
add_filter( 'wp_privacy_personal_data_exporters', function ( $list ) {
	$list['gildhart-travel-planner'] = array( 'exporter_friendly_name' => 'Travel Planner reminders', 'callback' => 'gtp_reminders_export' );
	return $list;
} );
add_filter( 'wp_privacy_personal_data_erasers', function ( $list ) {
	$list['gildhart-travel-planner'] = array( 'eraser_friendly_name' => 'Travel Planner reminders', 'callback' => 'gtp_reminders_erase' );
	return $list;
} );

/** What the card is handed: null for no reminders at all. */
function gtp_reminders_config() {
	if ( ! gtp_reminders_on() ) { return null; }
	return array(
		'weeks'    => GTP_REMIND_WEEKS,
		'advice'   => GTP_REMIND_ADVICE,
		'calendar' => gtp_calendar_url(),
		'email'    => gtp_reminders_email_on() && function_exists( 'rest_url' ) ? (string) rest_url( 'gtp/v1/remind' ) : '',
		'agree'    => gtp_reminders_consent_words(),
		/* The second box's words, where this pharmacy asks to keep in touch: '' for no second box and no name. */
		'keep'     => gtp_contacts_on() ? gtp_contacts_words() : '',
	);
}
