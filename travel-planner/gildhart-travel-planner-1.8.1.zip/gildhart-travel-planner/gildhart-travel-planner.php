<?php
/**
 * Plugin Name:       Travel Planner by Gildhart
 * Description:       "Where are you going?" for a pharmacy's travel clinic: any country, the vaccines the guidance lists for it, what each costs a dose here, how far ahead to book, and the day's outbreak notices. Every answer ends at a booking.
 * Version:           1.8.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Gildhart
 * Author URI:        https://gildhart.com
 * License:           GPL-2.0-or-later
 * Text Domain:       gildhart-travel-planner
 * Update URI:        https://raw.githubusercontent.com/Gildhart-pharmodigital/travel-planner-updates/main/travel-planner/info.json
 *
 * One pharmacy's travel desk, on any WordPress site, with nothing borrowed
 * from the theme around it.
 *
 *   [travel_planner]   the planner: the map, the box over every country, the trip card
 *   [travel_notices]   the latest outbreak notices, by date, disease and country
 *
 * Three things, kept apart because they change at different speeds and are
 * trusted differently:
 *
 *   data/        what the guidance says about each country, written in our
 *                own words from NaTHNaC's TravelHealthPro and dated. It ships
 *                with the plugin and changes only with a new version: a
 *                recommendation never moves on a site without a person
 *                having looked (workspace/travel-planner/build_pack.py).
 *   settings     what this pharmacy gives and charges, where it books, where
 *                it is: Travel Planner in wp-admin, or a file in the theme
 *                (gildhart-travel-planner.json) until someone saves there.
 *   notices      NaTHNaC's outbreak notices, read once a day: the date, the
 *                disease and the country, never their words or figures. A
 *                person can add, hide or correct one, and read again by hand.
 *
 *   guide        [travel_guide country="thailand"]: a country guide page's
 *                vaccines, prices, timing, facts, notices and booking, from the
 *                same pack and settings; a published page carrying it is that
 *                country's guide, and the planner links it.
 *   lookups      which countries visitors open, counted by month (the country
 *                and the month only), in Travel Planner > Look-ups.
 *
 *   licence      a key from Gildhart, for this site's address: with it the
 *                planner shows to everyone and takes each new version.
 *
 * It updates itself (includes/updates.php): WordPress finds each new version,
 * with each month's guidance, in Gildhart's public updates repository, and
 * installs it while automatic updates are on.
 *
 * The rules a card keeps, each learned on the first site this ran on:
 * a price is one dose's, never a course's total; a vaccine is named by its
 * type, never a brand; nobody is told they don't need one; every card ends
 * at a booking; and everything dated says its date.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'GTP_VERSION', '1.8.1' );
define( 'GTP_FILE', __FILE__ );
define( 'GTP_DIR', __DIR__ );

require_once GTP_DIR . '/includes/settings.php';
require_once GTP_DIR . '/includes/data.php';
require_once GTP_DIR . '/includes/notices.php';
require_once GTP_DIR . '/includes/cache.php';
require_once GTP_DIR . '/includes/licence.php';
require_once GTP_DIR . '/includes/planner.php';
require_once GTP_DIR . '/includes/admin.php';
require_once GTP_DIR . '/includes/lookups.php';
require_once GTP_DIR . '/includes/guide.php';
require_once GTP_DIR . '/includes/reminders.php';
require_once GTP_DIR . '/includes/contacts.php';
require_once GTP_DIR . '/includes/brevo.php';
require_once GTP_DIR . '/includes/posts.php';
require_once GTP_DIR . '/includes/updates.php';

/** The plugin's address, for its own script, stylesheet and data. */
function gtp_url( $path = '' ) {
	return plugins_url( ltrim( (string) $path, '/' ), GTP_FILE );
}

/** A file's own version, so a new one is never served from an old cache. */
function gtp_asset_version( $path ) {
	$file = GTP_DIR . '/' . ltrim( (string) $path, '/' );
	return is_file( $file ) ? GTP_VERSION . '.' . filemtime( $file ) : GTP_VERSION;
}

register_activation_hook( __FILE__, 'gtp_notices_schedule' );
register_deactivation_hook( __FILE__, 'gtp_notices_unschedule' );
