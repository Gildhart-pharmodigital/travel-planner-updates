<?php
/**
 * Brevo: the planner's emails sent properly, and the contacts list kept in the
 * pharmacy's own email tool.
 *
 * Why. An email is only as good as where it is sent from. A WordPress site's
 * own mail is for the odd password reset: many hosts will not carry marketing
 * email at all (Kinsta's rules say so) and cannot sign it as the site's
 * domain, so it lands in spam. Brevo is an email service that charges by the
 * emails sent, not by the size of the list, signs each email as the
 * pharmacy's own domain once three DNS records are added, and handles
 * unsubscribes, bounces and complaints. One Brevo account a pharmacy: its
 * list, its domain and its sending reputation are its own.
 *
 * What the connection does, once the pharmacy's Brevo API key is here:
 *   - the emails the planner sends to a visitor (the reminder's confirmation,
 *     the reminder itself) go through Brevo, from an address on the
 *     pharmacy's domain, but only once Brevo says that domain is
 *     authenticated. Until then, and whenever Brevo refuses or cannot be
 *     reached, they go the way they always did (wp_mail), so none is lost.
 *   - someone who ticks "also email me travel health news and offers"
 *     (includes/contacts.php) is added to the pharmacy's list in Brevo, with
 *     their first name, the country and the travel date, so the pharmacy's
 *     emails and sequences there can be about their trip. Only them: someone
 *     who asked for a reminder alone is never made a contact.
 *   - leaving is the same on both sides. Someone who leaves by the planner's
 *     link is taken off the list in Brevo and marked there as not to be
 *     emailed; someone who unsubscribes from one of the pharmacy's emails in
 *     Brevo is found at the next daily run and moved to "Asked to stop" here.
 *     WordPress's "Erase Personal Data" removes what the planner put in Brevo.
 *   - if Brevo cannot be reached, what was to be done there waits and is done
 *     at the next daily run.
 *
 * The key is a secret. It is kept in an option of its own (or as
 * GTP_BREVO_KEY in wp-config.php), never in the planner's settings: so it is
 * never read from a site's file (a theme may be public), never in "Copy these
 * settings to another site", never on a page, and the screen shows only its
 * last four characters.
 *
 * Brevo's API as its reference documents it (developers.brevo.com, read
 * 15 November 2026): the api-key header; POST /contacts, PUT and DELETE
 * /contacts/{email}, GET /contacts/lists/{id}/contacts, POST /smtp/email,
 * GET /account, GET /senders/domains/{domain}.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const GTP_BREVO_OPTION  = 'gtp_brevo';          // key, from_email, from_name, reply_to, list, send, sync
const GTP_BREVO_STATE   = 'gtp_brevo_state';    // what the last look at the account found, and the last thing that went wrong
const GTP_BREVO_PENDING = 'gtp_brevo_pending';  // email => add | stop | erase: what is still to be done in Brevo
const GTP_BREVO_API     = 'https://api.brevo.com/v3';
const GTP_BREVO_LIST    = 'Travel planner contacts';
const GTP_BREVO_BATCH   = 100;                  // how many waiting things one daily run does

/** This site's connection: never part of the planner's settings. */
function gtp_brevo() {
	$d = get_option( GTP_BREVO_OPTION, array() );
	$d = is_array( $d ) ? $d : array();
	return array(
		'key'        => (string) ( $d['key'] ?? '' ),
		'from_email' => (string) ( $d['from_email'] ?? '' ),
		'from_name'  => (string) ( $d['from_name'] ?? '' ),
		'reply_to'   => (string) ( $d['reply_to'] ?? '' ),
		'list'       => (int) ( $d['list'] ?? 0 ),
		'send'       => ! isset( $d['send'] ) || ! empty( $d['send'] ),
		'sync'       => ! isset( $d['sync'] ) || ! empty( $d['sync'] ),
	);
}

/** The key in force: wp-config's, or the one saved on the screen. */
function gtp_brevo_key() {
	if ( defined( 'GTP_BREVO_KEY' ) && '' !== (string) GTP_BREVO_KEY ) { return (string) GTP_BREVO_KEY; }
	return gtp_brevo()['key'];
}

function gtp_brevo_connected() {
	return '' !== gtp_brevo_key();
}

/** A key as the screen may show it: its last four characters, and nothing else. */
function gtp_brevo_key_shown() {
	$k = gtp_brevo_key();
	return '' === $k ? '' : '…' . substr( $k, -4 );
}

function gtp_brevo_state() {
	$d = get_option( GTP_BREVO_STATE, array() );
	return is_array( $d ) ? $d : array();
}

function gtp_brevo_note( $changes ) {
	update_option( GTP_BREVO_STATE, array_merge( gtp_brevo_state(), $changes ), false );
}

/** The domain an address is on. */
function gtp_brevo_domain_of( $email ) {
	$at = strrpos( (string) $email, '@' );
	return false === $at ? '' : strtolower( substr( (string) $email, $at + 1 ) );
}

/**
 * One request to Brevo. Returns ok, code, data (the decoded answer) and error
 * (Brevo's own words for a refusal, or that it could not be reached). The key
 * goes in the header and nowhere else.
 */
function gtp_brevo_call( $method, $path, $body = null, $query = array() ) {
	$key = gtp_brevo_key();
	if ( '' === $key ) { return array( 'ok' => false, 'code' => 0, 'data' => null, 'error' => 'No API key.' ); }
	$url  = GTP_BREVO_API . $path . ( $query ? '?' . http_build_query( $query ) : '' );
	$args = array(
		'method'  => $method,
		'timeout' => 8,
		'headers' => array( 'api-key' => $key, 'accept' => 'application/json', 'content-type' => 'application/json' ),
	);
	if ( null !== $body ) { $args['body'] = wp_json_encode( $body ); }
	$r = wp_remote_request( $url, $args );
	if ( is_wp_error( $r ) ) { return array( 'ok' => false, 'code' => 0, 'data' => null, 'error' => 'Brevo could not be reached.' ); }
	$code = (int) wp_remote_retrieve_response_code( $r );
	$data = json_decode( (string) wp_remote_retrieve_body( $r ), true );
	$data = is_array( $data ) ? $data : null;
	if ( $code >= 200 && $code < 300 ) { return array( 'ok' => true, 'code' => $code, 'data' => $data, 'error' => '' ); }
	$says = $data ? trim( (string) ( $data['message'] ?? $data['code'] ?? '' ) ) : '';
	if ( 401 === $code ) { $says = 'Brevo does not know this API key.'; }
	if ( $code < 100 || $code >= 500 ) { $says = 'Brevo could not be reached.'; }
	return array( 'ok' => false, 'code' => $code, 'data' => $data, 'error' => '' !== $says ? wp_strip_all_tags( $says ) : 'Brevo refused the request (' . $code . ').' );
}

/* ---- what the account is, and whether it is ready ------------------------------------------ */

/**
 * Look at the account: who it is, the sending domain's state and the records
 * it still needs, the lists, and the contact fields the planner fills in
 * (made here if the account lacks them). Kept as the state the screen shows.
 */
function gtp_brevo_refresh() {
	$b     = gtp_brevo();
	$state = array(
		'checked' => wp_date( 'Y-m-d H:i', gtp_notices_now() ), 'ok' => false, 'error' => '',
		'account' => array(), 'domain' => array(), 'lists' => array(), 'firstname' => 'FIRSTNAME', 'fields' => array(),
	);
	if ( ! gtp_brevo_connected() ) { $state['error'] = 'No API key.'; update_option( GTP_BREVO_STATE, $state, false ); return $state; }

	$a = gtp_brevo_call( 'GET', '/account' );
	if ( ! $a['ok'] ) { $state['error'] = $a['error']; update_option( GTP_BREVO_STATE, array_merge( gtp_brevo_state(), $state ), false ); return $state; }
	$plan             = (array) ( $a['data']['plan'][0] ?? array() );
	$state['ok']      = true;
	$state['account'] = array(
		'company' => (string) ( $a['data']['companyName'] ?? '' ),
		'email'   => (string) ( $a['data']['email'] ?? '' ),
		'plan'    => (string) ( $plan['type'] ?? '' ),
		'credits' => isset( $plan['credits'] ) && 'sendLimit' === ( $plan['creditsType'] ?? '' ) ? (int) $plan['credits'] : null,
	);

	/* The sending domain: authenticated or not, and the records Brevo is waiting for. */
	$domain = gtp_brevo_domain_of( $b['from_email'] );
	if ( '' !== $domain ) {
		$d    = gtp_brevo_call( 'GET', '/senders/domains/' . rawurlencode( $domain ) );
		$recs = array();
		foreach ( array( 'brevo_code' => 'Brevo code', 'dkim_record' => 'DKIM', 'dmarc_record' => 'DMARC' ) as $k => $label ) {
			$r = $d['ok'] ? ( $d['data']['dns_records'][ $k ] ?? null ) : null;
			if ( is_array( $r ) ) {
				$recs[] = array( 'what' => $label, 'host' => (string) ( $r['host_name'] ?? '' ), 'type' => (string) ( $r['type'] ?? '' ), 'value' => (string) ( $r['value'] ?? '' ), 'ok' => ! empty( $r['status'] ) );
			}
		}
		$state['domain'] = array(
			'name'          => $domain,
			'known'         => $d['ok'],
			'authenticated' => $d['ok'] && ! empty( $d['data']['authenticated'] ),
			'records'       => $recs,
		);
	}

	/* The lists, to choose one from. */
	for ( $offset = 0; $offset < 500; $offset += 50 ) {
		$l = gtp_brevo_call( 'GET', '/contacts/lists', null, array( 'limit' => 50, 'offset' => $offset ) );
		if ( ! $l['ok'] ) { break; }
		$rows = (array) ( $l['data']['lists'] ?? array() );
		foreach ( $rows as $row ) { $state['lists'][ (int) $row['id'] ] = (string) $row['name']; }
		if ( count( $rows ) < 50 ) { break; }
	}

	/* The fields the planner fills in: the account's own first-name field, and three of ours. */
	$have = array();
	$f    = gtp_brevo_call( 'GET', '/contacts/attributes' );
	foreach ( (array) ( $f['ok'] ? ( $f['data']['attributes'] ?? array() ) : array() ) as $row ) { $have[ strtoupper( (string) ( $row['name'] ?? '' ) ) ] = true; }
	if ( $f['ok'] ) {
		if ( isset( $have['FIRSTNAME'] ) ) { $state['firstname'] = 'FIRSTNAME'; }
		elseif ( isset( $have['FNAME'] ) ) { $state['firstname'] = 'FNAME'; }
		else { $have['FIRSTNAME'] = gtp_brevo_call( 'POST', '/contacts/attributes/normal/FIRSTNAME', array( 'type' => 'text' ) )['ok']; }
		foreach ( array( 'TRIP_COUNTRY' => 'text', 'TRIP_DATE' => 'date', 'AGREED_ON' => 'date' ) as $name => $type ) {
			if ( empty( $have[ $name ] ) ) { $have[ $name ] = gtp_brevo_call( 'POST', '/contacts/attributes/normal/' . $name, array( 'type' => $type ) )['ok']; }
		}
		foreach ( array( $state['firstname'], 'TRIP_COUNTRY', 'TRIP_DATE', 'AGREED_ON' ) as $name ) { if ( ! empty( $have[ $name ] ) ) { $state['fields'][] = $name; } }
	}
	update_option( GTP_BREVO_STATE, array_merge( gtp_brevo_state(), $state ), false );
	return $state;
}

/** Whether the planner's emails go through Brevo: a key, the switch, an address to send from, and its domain authenticated there. */
function gtp_brevo_sending() {
	$b = gtp_brevo();
	if ( ! gtp_brevo_connected() || ! $b['send'] || '' === $b['from_email'] ) { return false; }
	$d = (array) ( gtp_brevo_state()['domain'] ?? array() );
	return ! empty( $d['authenticated'] ) && gtp_brevo_domain_of( $b['from_email'] ) === ( $d['name'] ?? '' );
}

/** Whether contacts are kept in a Brevo list: a key, the switch and a list. */
function gtp_brevo_syncing() {
	$b = gtp_brevo();
	return gtp_brevo_connected() && $b['sync'] && $b['list'] > 0;
}

/* ---- the planner's emails ------------------------------------------------------------------- */

/** An email's words as a simple page: paragraphs, and its addresses as links. */
function gtp_mail_html( $text ) {
	$out = '';
	foreach ( preg_split( '/\n{2,}/', trim( (string) $text ) ) as $para ) {
		$p    = preg_replace( '~(https?://[^\s<]+)~', '<a href="$1">$1</a>', esc_html( $para ) );
		$out .= '<p>' . nl2br( $p ) . '</p>';
	}
	return '<div style="font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.5;color:#1a1a1a">' . $out . '</div>';
}

/**
 * Send one of the planner's emails to a visitor: through Brevo where that is
 * ready, and the site's own way otherwise or if Brevo will not take it, so an
 * email someone asked for is never lost to a setting. Returns whether it went.
 */
function gtp_mail( $to, $subject, $body, $kind = 'planner' ) {
	if ( gtp_brevo_sending() ) {
		$b    = gtp_brevo();
		$name = '' !== $b['from_name'] ? $b['from_name'] : (string) gtp_setting( 'pharmacy' );
		$mail = array(
			'sender'      => array( 'email' => $b['from_email'], 'name' => function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 70, 'UTF-8' ) : substr( $name, 0, 70 ) ),
			'to'          => array( array( 'email' => (string) $to ) ),
			'subject'     => (string) $subject,
			'htmlContent' => gtp_mail_html( $body ),
			'textContent' => (string) $body,
			'tags'        => array( 'travel-planner', (string) $kind ),
		);
		if ( '' !== $b['reply_to'] ) { $mail['replyTo'] = array( 'email' => $b['reply_to'] ); }
		$r = gtp_brevo_call( 'POST', '/smtp/email', $mail );
		if ( $r['ok'] ) {
			gtp_brevo_note( array( 'sent_last' => wp_date( 'Y-m-d H:i', gtp_notices_now() ), 'sent_error' => '' ) );
			return true;
		}
		gtp_brevo_note( array( 'sent_error' => wp_date( 'Y-m-d H:i', gtp_notices_now() ) . ': ' . $r['error'] ) );
	}
	return (bool) wp_mail( $to, $subject, $body );
}

/* ---- the contacts list, in Brevo -------------------------------------------------------------- */

function gtp_brevo_pending() {
	$d = get_option( GTP_BREVO_PENDING, array() );
	return is_array( $d ) ? $d : array();
}

function gtp_brevo_wait( $email, $what ) {
	$p                                      = gtp_brevo_pending();
	$p[ strtolower( trim( (string) $email ) ) ] = $what;
	update_option( GTP_BREVO_PENDING, $p, false );
}

function gtp_brevo_done( $email ) {
	$p = gtp_brevo_pending();
	unset( $p[ strtolower( trim( (string) $email ) ) ] );
	if ( $p ) { update_option( GTP_BREVO_PENDING, $p, false ); } else { delete_option( GTP_BREVO_PENDING ); }
}

/** Add a contact of the planner's to the list in Brevo, or bring them up to date. Returns whether Brevo took it. */
function gtp_brevo_push( $email ) {
	$c = gtp_contact_of( $email );
	if ( ! $c ) { return true; }  // they left before it could be done: nothing to add
	$state  = gtp_brevo_state();
	$fields = (array) ( $state['fields'] ?? array() );
	$names  = gtp_country_names();
	$first  = (string) ( $state['firstname'] ?? 'FIRSTNAME' );
	$all    = array(
		$first         => (string) $c['name'],
		'TRIP_COUNTRY' => (string) ( $names[ $c['slug'] ] ?? '' ),
		'TRIP_DATE'    => (string) $c['fly'],
		'AGREED_ON'    => (string) $c['made'],
	);
	$attrs = array();
	foreach ( $all as $k => $v ) { if ( in_array( $k, $fields, true ) && '' !== $v ) { $attrs[ $k ] = $v; } }
	$body = array(
		'email'            => (string) $c['email'],
		'listIds'          => array( gtp_brevo()['list'] ),
		'updateEnabled'    => true,
		/* They have just ticked the box: someone who unsubscribed before and asks again is emailed again. */
		'emailBlacklisted' => false,
	);
	if ( $attrs ) { $body['attributes'] = $attrs; }
	return gtp_brevo_call( 'POST', '/contacts', $body )['ok'];
}

/** Someone left by the planner's link: off the list in Brevo, and marked there as not to be emailed. */
function gtp_brevo_stop( $email ) {
	$r = gtp_brevo_call( 'PUT', '/contacts/' . rawurlencode( strtolower( trim( (string) $email ) ) ), array( 'emailBlacklisted' => true, 'unlinkListIds' => array( gtp_brevo()['list'] ) ) );
	return $r['ok'] || 404 === $r['code'];  // not there: nothing to stop
}

/**
 * "Erase Personal Data": what the planner put in Brevo is removed. Off the
 * list and the trip forgotten; and the contact itself deleted, unless they
 * are on another of the pharmacy's lists, which is not the planner's to
 * delete.
 */
function gtp_brevo_erase( $email ) {
	$id   = rawurlencode( strtolower( trim( (string) $email ) ) );
	$list = gtp_brevo()['list'];
	$g    = gtp_brevo_call( 'GET', '/contacts/' . $id );
	if ( 404 === $g['code'] ) { return true; }
	if ( ! $g['ok'] ) { return false; }
	$others = array_diff( array_map( 'intval', (array) ( $g['data']['listIds'] ?? array() ) ), array( $list ) );
	if ( ! $others ) {
		$d = gtp_brevo_call( 'DELETE', '/contacts/' . $id );
		if ( $d['ok'] || 404 === $d['code'] ) { return true; }
		/* Brevo will not delete the account owner's own contact (405): what the planner put there is removed instead. */
		if ( 405 !== $d['code'] ) { return false; }
	}
	$blank = array();
	foreach ( array( 'TRIP_COUNTRY', 'TRIP_DATE', 'AGREED_ON' ) as $k ) { if ( in_array( $k, (array) ( gtp_brevo_state()['fields'] ?? array() ), true ) ) { $blank[ $k ] = ''; } }
	$body = array( 'unlinkListIds' => array( $list ) );
	if ( $blank ) { $body['attributes'] = $blank; }
	return gtp_brevo_call( 'PUT', '/contacts/' . $id, $body )['ok'];
}

/** Do one thing in Brevo now; if it cannot be done, it waits for the daily run. */
function gtp_brevo_do( $email, $what ) {
	if ( ! gtp_brevo_syncing() ) { return; }
	$ok = 'add' === $what ? gtp_brevo_push( $email ) : ( 'stop' === $what ? gtp_brevo_stop( $email ) : gtp_brevo_erase( $email ) );
	if ( $ok ) { gtp_brevo_done( $email ); } else { gtp_brevo_wait( $email, $what ); }
}

/* What happens to the planner's own list (includes/contacts.php) happens in Brevo. */
add_action( 'gtp_contact_added', function ( $email ) { gtp_brevo_do( $email, 'add' ); } );
add_action( 'gtp_contact_stopped', function ( $email ) { if ( empty( $GLOBALS['gtp_brevo_told_us'] ) ) { gtp_brevo_do( $email, 'stop' ); } } );
add_action( 'gtp_contact_erased', function ( $email ) { gtp_brevo_do( $email, 'erase' ); } );

/** Everyone on the planner's list is to be added to Brevo: when the connection is new, or its list changes. */
function gtp_brevo_queue_all() {
	$p = gtp_brevo_pending();
	foreach ( array_keys( gtp_contacts() ) as $email ) { if ( ! isset( $p[ $email ] ) ) { $p[ $email ] = 'add'; } }
	if ( $p ) { update_option( GTP_BREVO_PENDING, $p, false ); }
}

/**
 * Who has unsubscribed in Brevo: from one of the pharmacy's own emails there.
 * They are moved to "Asked to stop" here, so the two lists say the same. The
 * pharmacy is not emailed about it: Brevo already will not email them.
 * Returns how many.
 */
function gtp_brevo_pull() {
	$mine = gtp_contacts();
	if ( ! $mine ) { return 0; }
	$list = gtp_brevo()['list'];
	$gone = 0;
	for ( $offset = 0; $offset < 20000; $offset += 500 ) {
		$r = gtp_brevo_call( 'GET', '/contacts/lists/' . $list . '/contacts', null, array( 'limit' => 500, 'offset' => $offset ) );
		if ( ! $r['ok'] ) { break; }
		$rows = (array) ( $r['data']['contacts'] ?? array() );
		foreach ( $rows as $row ) {
			$email = strtolower( (string) ( $row['email'] ?? '' ) );
			$out   = ! empty( $row['emailBlacklisted'] ) || in_array( $list, array_map( 'intval', (array) ( $row['listUnsubscribed'] ?? array() ) ), true );
			if ( '' === $email || ! $out || ! isset( $mine[ $email ] ) || 'add' === ( gtp_brevo_pending()[ $email ] ?? '' ) ) { continue; }
			/* Brevo told us: there is nothing to tell Brevo. */
			$GLOBALS['gtp_brevo_told_us'] = true;
			if ( gtp_contacts_remove( $email ) ) { $gone++; gtp_reminder_count( 'stopped' ); }
			unset( $GLOBALS['gtp_brevo_told_us'] );
		}
		if ( count( $rows ) < 500 ) { break; }
	}
	return $gone;
}

/** The daily run: what was waiting is done, who unsubscribed in Brevo is found, and the account is looked at again. */
function gtp_brevo_daily() {
	if ( ! gtp_brevo_connected() ) { return; }
	if ( gtp_brevo_syncing() ) {
		$n = 0;
		foreach ( gtp_brevo_pending() as $email => $what ) {
			if ( $n++ >= GTP_BREVO_BATCH ) { break; }
			gtp_brevo_do( $email, $what );
		}
		gtp_brevo_pull();
	}
	gtp_brevo_refresh();
}
/* Before the day's reminders are sent (30), so a reminder knows who is still on the list. */
add_action( GTP_NOTICES_HOOK, 'gtp_brevo_daily', 25 );

/** One line for the site's privacy notice, once the planner's emails go through Brevo. */
function gtp_brevo_privacy_line() {
	return 'The emails our travel planner sends are sent for us by Brevo, an email service. It holds your email address, and your first name and trip if you asked us to keep in touch, on our behalf and for that purpose only.';
}

/* ---- Travel Planner > Email ---------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_submenu_page( 'gtp-settings', 'Email', 'Email', 'manage_options', 'gtp-email', 'gtp_admin_email_page' );
}, 45 );

add_action( 'admin_post_gtp_brevo_save', function () {
	gtp_admin_guard( 'gtp_brevo_save' );
	$in  = isset( $_POST['brevo'] ) && is_array( $_POST['brevo'] ) ? wp_unslash( $_POST['brevo'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- each value cleaned below
	$was = gtp_brevo();
	$now = $was;
	/* A key is replaced only by a new one, and removed only by saying so: the box is never filled in with it. */
	$key = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $in['key'] ?? '' ) );
	if ( ! empty( $in['forget'] ) ) { $now['key'] = ''; } elseif ( '' !== $key ) { $now['key'] = substr( $key, 0, 200 ); }
	$from              = trim( (string) ( $in['from_email'] ?? '' ) );
	$now['from_email'] = ( '' !== $from && is_email( $from ) ) ? strtolower( $from ) : '';
	$now['from_name']  = trim( wp_strip_all_tags( (string) ( $in['from_name'] ?? '' ) ) );
	$reply             = trim( (string) ( $in['reply_to'] ?? '' ) );
	$now['reply_to']   = ( '' !== $reply && is_email( $reply ) ) ? $reply : '';
	$now['send']       = ! empty( $in['send'] );
	$now['sync']       = ! empty( $in['sync'] );
	$list              = (string) ( $in['list'] ?? '' );
	$now['list']       = 'new' === $list ? 0 : max( 0, (int) $list );
	update_option( GTP_BREVO_OPTION, $now, false );
	if ( ! gtp_brevo_connected() ) {
		/* The connection is gone: nothing waits for it. */
		delete_option( GTP_BREVO_STATE );
		delete_option( GTP_BREVO_PENDING );
		gtp_admin_back( 'gtp-email', array( 'gtp' => 'brevo-off' ) );
	}
	$state = gtp_brevo_refresh();
	/* "Make me a list": the one of this name if the account has it, or a new one in its first folder. */
	if ( 'new' === $list && $state['ok'] ) {
		$id = (int) array_search( GTP_BREVO_LIST, $state['lists'], true );
		if ( ! $id ) {
			$folders = gtp_brevo_call( 'GET', '/contacts/folders', null, array( 'limit' => 10, 'offset' => 0 ) );
			$folder  = (int) ( $folders['data']['folders'][0]['id'] ?? 0 );
			if ( ! $folder ) { $folder = (int) ( gtp_brevo_call( 'POST', '/contacts/folders', array( 'name' => 'Travel planner' ) )['data']['id'] ?? 0 ); }
			if ( $folder ) { $id = (int) ( gtp_brevo_call( 'POST', '/contacts/lists', array( 'name' => GTP_BREVO_LIST, 'folderId' => $folder ) )['data']['id'] ?? 0 ); }
		}
		if ( $id ) {
			$now['list'] = $id;
			update_option( GTP_BREVO_OPTION, $now, false );
			gtp_brevo_refresh();
		}
	}
	/* A new connection, or another list: everyone already on the planner's list is to be added there. */
	if ( gtp_brevo_syncing() && ( $now['list'] !== $was['list'] || ! $was['sync'] || '' === $was['key'] ) ) { gtp_brevo_queue_all(); }
	gtp_admin_back( 'gtp-email', array( 'gtp' => $state['ok'] ? 'brevo-saved' : 'brevo-failed' ) );
} );

add_action( 'admin_post_gtp_brevo_check', function () {
	gtp_admin_guard( 'gtp_brevo_check' );
	$state = gtp_brevo_refresh();
	gtp_admin_back( 'gtp-email', array( 'gtp' => $state['ok'] ? 'brevo-checked' : 'brevo-failed' ) );
} );

add_action( 'admin_post_gtp_brevo_test', function () {
	gtp_admin_guard( 'gtp_brevo_test' );
	if ( ! gtp_brevo_sending() ) { gtp_admin_back( 'gtp-email', array( 'gtp' => 'brevo-not-ready' ) ); }
	$to   = (string) get_option( 'admin_email' );
	$r    = gtp_brevo_call( 'POST', '/smtp/email', array(
		'sender'      => array( 'email' => gtp_brevo()['from_email'], 'name' => '' !== gtp_brevo()['from_name'] ? gtp_brevo()['from_name'] : (string) gtp_setting( 'pharmacy' ) ),
		'to'          => array( array( 'email' => $to ) ),
		'subject'     => 'Travel planner: a test email through Brevo',
		'htmlContent' => gtp_mail_html( "This is a test from your travel planner, sent through Brevo.\n\nIf it arrived in your inbox and not in spam, the planner's emails will too." ),
		'textContent' => "This is a test from your travel planner, sent through Brevo.\n\nIf it arrived in your inbox and not in spam, the planner's emails will too.",
		'tags'        => array( 'travel-planner', 'test' ),
	) );
	if ( ! $r['ok'] ) { gtp_brevo_note( array( 'sent_error' => wp_date( 'Y-m-d H:i', gtp_notices_now() ) . ': ' . $r['error'] ) ); }
	gtp_admin_back( 'gtp-email', array( 'gtp' => $r['ok'] ? 'brevo-test-sent' : 'brevo-test-failed' ) );
} );

function gtp_admin_email_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$b      = gtp_brevo();
	$state  = gtp_brevo_state();
	$on     = gtp_brevo_connected();
	$fixed  = defined( 'GTP_BREVO_KEY' ) && '' !== (string) GTP_BREVO_KEY;
	$domain = (array) ( $state['domain'] ?? array() );
	$lists  = (array) ( $state['lists'] ?? array() );
	$wait   = gtp_brevo_pending();
	$m      = isset( $_GET['gtp'] ) ? sanitize_text_field( wp_unslash( $_GET['gtp'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- a message, nothing is changed
	$says   = array(
		'brevo-saved'       => 'Saved, and Brevo answered.',
		'brevo-off'         => 'The key is removed. The planner\'s emails go the site\'s own way again, and nothing is sent to Brevo.',
		'brevo-failed'      => 'Saved, but Brevo did not answer as expected: see below.',
		'brevo-checked'     => 'Checked again.',
		'brevo-not-ready'   => 'No test was sent: the planner is not sending through Brevo yet (see below).',
		'brevo-test-sent'   => 'A test email is on its way to ' . get_option( 'admin_email' ) . '. Look for it in the inbox, then in spam.',
		'brevo-test-failed' => 'Brevo would not send the test: see below.',
	);
	?>
	<div class="wrap" data-gtp-admin="email">
		<h1>Email</h1>
		<?php if ( isset( $says[ $m ] ) ) : ?><div class="notice notice-info is-dismissible" data-gtp-message><p><?php echo esc_html( $says[ $m ] ); ?></p></div><?php endif; ?>
		<p>The planner emails a visitor who asks for a reminder, and keeps a contacts list of those who ask to hear from you. Connect it to your pharmacy's own <strong>Brevo</strong> account and those emails are sent from your own domain, signed as yours, and the contacts list is kept in Brevo for the emails you send from there. Without a key here, nothing is sent to Brevo and the planner's emails go the site's own way.</p>

		<p data-gtp-brevo-state="<?php echo esc_attr( ! $on ? 'off' : ( empty( $state['ok'] ) ? 'failed' : ( gtp_brevo_sending() ? 'sending' : 'connected' ) ) ); ?>">
			<?php if ( ! $on ) : ?>
				<strong>Not connected.</strong>
			<?php elseif ( empty( $state['ok'] ) ) : ?>
				<strong>Brevo did not answer as expected:</strong> <?php echo esc_html( (string) ( $state['error'] ?? 'not checked yet' ) ); ?>
			<?php else : ?>
				<strong>Connected</strong> to <?php echo esc_html( (string) ( $state['account']['company'] ?? '' ) ); ?> (<?php echo esc_html( (string) ( $state['account']['email'] ?? '' ) ); ?>), on Brevo's <?php echo esc_html( (string) ( $state['account']['plan'] ?? '' ) ); ?> plan<?php if ( isset( $state['account']['credits'] ) ) : ?>, <?php echo (int) $state['account']['credits']; ?> emails left to send<?php endif; ?>. Last checked <?php echo esc_html( (string) $state['checked'] ); ?>.
			<?php endif; ?>
		</p>

		<?php if ( $on && ! empty( $state['ok'] ) ) : ?>
		<h2>Is it ready to send?</h2>
		<p data-gtp-brevo-sending>
			<?php if ( gtp_brevo_sending() ) : ?>
				<strong>Yes.</strong> The planner's emails to visitors are sent through Brevo, from <?php echo esc_html( $b['from_email'] ); ?>. If Brevo ever refuses one, it is sent the site's own way instead.
			<?php elseif ( ! $b['send'] ) : ?>
				"Send the planner's emails through Brevo" is unticked: they go the site's own way.
			<?php elseif ( '' === $b['from_email'] ) : ?>
				<strong>Not yet:</strong> give an address to send from, on your pharmacy's own domain.
			<?php elseif ( empty( $domain['known'] ) ) : ?>
				<strong>Not yet:</strong> Brevo does not know the domain <code><?php echo esc_html( (string) ( $domain['name'] ?? '' ) ); ?></code>. In Brevo, open Senders, Domains &amp; IPs &rsaquo; Domains &rsaquo; Add a domain, add it, then press "Check again" here for the records to add. Until then the planner's emails go the site's own way.
			<?php else : ?>
				<strong>Not yet:</strong> <code><?php echo esc_html( (string) $domain['name'] ); ?></code> is not authenticated in Brevo. Add the records below where the domain's DNS is managed, press Authenticate in Brevo, then "Check again" here. Until then the planner's emails go the site's own way.
			<?php endif; ?>
		</p>
		<?php if ( ! empty( $domain['records'] ) ) : ?>
		<table class="widefat striped" style="max-width:1000px" data-gtp-brevo-records>
			<thead><tr><th>Record</th><th>Type</th><th>Host</th><th>Value</th><th>Found?</th></tr></thead>
			<tbody>
			<?php foreach ( $domain['records'] as $r ) : ?>
				<tr><td><?php echo esc_html( $r['what'] ); ?></td><td><?php echo esc_html( $r['type'] ); ?></td><td><code><?php echo esc_html( $r['host'] ); ?></code></td><td><code style="word-break:break-all"><?php echo esc_html( $r['value'] ); ?></code></td><td><?php echo $r['ok'] ? 'Yes' : '<strong>Not yet</strong>'; ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
		<?php if ( '' !== (string) ( $state['sent_error'] ?? '' ) ) : ?><p data-gtp-brevo-error>The last email Brevo would not send (it went the site's own way): <?php echo esc_html( (string) $state['sent_error'] ); ?></p><?php endif; ?>
		<div style="margin:12px 0">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="gtp_brevo_check"><?php wp_nonce_field( 'gtp_brevo_check' ); ?>
				<button type="submit" class="button" data-gtp-brevo-check>Check again</button>
			</form>
			<?php if ( gtp_brevo_sending() ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="gtp_brevo_test"><?php wp_nonce_field( 'gtp_brevo_test' ); ?>
				<button type="submit" class="button" data-gtp-brevo-test>Send a test email to <?php echo esc_html( (string) get_option( 'admin_email' ) ); ?></button>
			</form>
			<?php endif; ?>
		</div>

		<h2>The contacts list</h2>
		<p data-gtp-brevo-sync>
			<?php if ( gtp_brevo_syncing() ) : ?>
				Everyone who asks to be kept in touch is added to the Brevo list <strong><?php echo esc_html( (string) ( $lists[ $b['list'] ] ?? ( '#' . $b['list'] ) ) ); ?></strong>, with their first name, the country and their travel date (<?php echo esc_html( implode( ', ', (array) ( $state['fields'] ?? array() ) ) ); ?>). <strong><?php echo (int) count( gtp_contacts() ); ?></strong> on the planner's list<?php if ( $wait ) : ?>, <strong data-gtp-brevo-waiting><?php echo (int) count( $wait ); ?></strong> waiting to be done in Brevo at the next daily run<?php endif; ?>. Someone who unsubscribes in Brevo is moved to "Asked to stop" here at the next daily run.
			<?php elseif ( ! $b['sync'] ) : ?>
				"Add people who ask to be kept in touch" is unticked: the list stays here (Travel Planner &rsaquo; Contacts) and nothing is added in Brevo.
			<?php else : ?>
				<strong>Not yet:</strong> choose the Brevo list they are added to.
			<?php endif; ?>
		</p>
		<?php endif; ?>

		<h2>The connection</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-gtp-brevo-form>
			<input type="hidden" name="action" value="gtp_brevo_save">
			<?php wp_nonce_field( 'gtp_brevo_save' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="gtp-brevo-key">Brevo API key</label></th><td>
					<?php if ( $fixed ) : ?>
						<p data-gtp-brevo-key-shown>Set in wp-config.php (<code>GTP_BREVO_KEY</code>), ending <?php echo esc_html( gtp_brevo_key_shown() ); ?>.</p>
					<?php else : ?>
						<input type="password" id="gtp-brevo-key" name="brevo[key]" value="" class="regular-text" autocomplete="off" spellcheck="false" placeholder="<?php echo $on ? 'A key is saved: leave this empty to keep it' : 'xkeysib-…'; ?>">
						<?php if ( $on ) : ?><p data-gtp-brevo-key-shown>A key is saved, ending <code><?php echo esc_html( gtp_brevo_key_shown() ); ?></code>. <label><input type="checkbox" name="brevo[forget]" value="1"> Remove it</label></p><?php endif; ?>
						<p class="description">In Brevo: your name (top right) &rsaquo; SMTP &amp; API &rsaquo; API keys &rsaquo; Generate a new API key. It is a password: it is kept on this site only, never shown again here, and never copied with the planner's settings.</p>
					<?php endif; ?>
				</td></tr>
				<tr><th scope="row"><label for="gtp-brevo-from">Send from</label></th><td>
					<input type="email" id="gtp-brevo-from" name="brevo[from_email]" value="<?php echo esc_attr( $b['from_email'] ); ?>" class="regular-text" placeholder="travel@yourpharmacy.co.uk">
					<p class="description">An address on your pharmacy's own domain. Its domain must be authenticated in Brevo before anything is sent from it.</p>
				</td></tr>
				<tr><th scope="row"><label for="gtp-brevo-name">From name</label></th><td>
					<input type="text" id="gtp-brevo-name" name="brevo[from_name]" value="<?php echo esc_attr( $b['from_name'] ); ?>" class="regular-text" maxlength="70" placeholder="<?php echo esc_attr( (string) gtp_setting( 'pharmacy' ) ); ?>">
				</td></tr>
				<tr><th scope="row"><label for="gtp-brevo-reply">Replies go to</label></th><td>
					<input type="email" id="gtp-brevo-reply" name="brevo[reply_to]" value="<?php echo esc_attr( $b['reply_to'] ); ?>" class="regular-text">
					<p class="description">An inbox someone reads. Empty: replies go to the address above.</p>
				</td></tr>
				<tr><th scope="row">The planner's emails</th><td>
					<label><input type="checkbox" name="brevo[send]" value="1" <?php checked( $b['send'] ); ?>> Send the planner's emails to visitors through Brevo</label>
				</td></tr>
				<tr><th scope="row"><label for="gtp-brevo-list">The contacts list</label></th><td>
					<label><input type="checkbox" name="brevo[sync]" value="1" <?php checked( $b['sync'] ); ?>> Add people who ask to be kept in touch to this Brevo list:</label><br>
					<select id="gtp-brevo-list" name="brevo[list]">
						<option value="0">Choose a list</option>
						<?php foreach ( $lists as $id => $name ) : ?><option value="<?php echo (int) $id; ?>" <?php selected( $b['list'], $id ); ?>><?php echo esc_html( $name ); ?></option><?php endforeach; ?>
						<?php if ( ! in_array( GTP_BREVO_LIST, $lists, true ) ) : ?><option value="new">Make a list called "<?php echo esc_html( GTP_BREVO_LIST ); ?>"</option><?php endif; ?>
					</select>
					<p class="description"><?php echo $lists ? 'A list of its own for the travel planner is best.' : 'Save the key first: the account\'s lists are then offered here.'; ?></p>
				</td></tr>
			</table>
			<p><button type="submit" class="button button-primary" data-gtp-brevo-save>Save and check</button></p>
		</form>

		<h2>For the site's privacy notice</h2>
		<p>Add this line to the privacy notice before the planner sends through Brevo:</p>
		<p><textarea class="large-text" rows="2" readonly data-gtp-brevo-privacy><?php echo esc_textarea( gtp_brevo_privacy_line() ); ?></textarea></p>
	</div>
	<?php
}
